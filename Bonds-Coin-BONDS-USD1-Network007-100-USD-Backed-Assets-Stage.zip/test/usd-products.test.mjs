import test from 'node:test';
import assert from 'node:assert/strict';
import { loadUsdBackedProducts, reserveEligibleProducts } from '../network007/usd-products.mjs';

test('Network 007 contains exactly 100 USD-backed reference products', () => {
  const c = loadUsdBackedProducts();
  assert.equal(c.productCount, 100);
  assert.equal(c.products.length, 100);
  assert.equal(new Set(c.products.map(x => x.productId)).size, 100);
});

test('reference products cannot create reserve credit automatically', () => {
  const c = loadUsdBackedProducts();
  assert.equal(reserveEligibleProducts(c).length, 0);
  assert.equal(c.policy.noAutomaticMint, true);
});
