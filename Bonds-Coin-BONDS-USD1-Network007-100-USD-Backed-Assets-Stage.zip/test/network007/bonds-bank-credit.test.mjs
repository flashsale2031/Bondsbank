import test from 'node:test';
import assert from 'node:assert/strict';
import { Network007Registry, registerBondsBankCredit, BONDS_BANK_CREDIT } from '../../network007/index.mjs';

test('007 registers Bonds Bank credit token BBUSD', () => {
  const r = new Network007Registry();
  const asset = registerBondsBankCredit(r);
  assert.equal(asset.assetId, 'bondsbank:007:BBUSD');
  assert.equal(asset.symbol, 'BBUSD');
  assert.equal(asset.chainId, '7007');
  assert.equal(asset.decimals, 6);
  assert.equal(asset.assetClass, 'tokenized-bank-credit');
  assert.equal(asset.mintPolicy, 'verified-deposit-required');
  assert.equal(asset.redemptionPolicy, 'settlement-confirmation-required');
});

test('007 keeps BBUSD supply authority tied to verified reserve policy', () => {
  assert.match(BONDS_BANK_CREDIT.backing, /1:1 verified USD reserve/);
  assert.equal(BONDS_BANK_CREDIT.mintPolicy, 'verified-deposit-required');
  assert.equal(BONDS_BANK_CREDIT.bridgePolicy, 'verified-proof-and-provider-adapter-required');
});
