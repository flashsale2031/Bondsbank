import fs from 'node:fs';
import path from 'node:path';

const products = [];
const add = (issuer, fund, cls, ticker, type, source) => products.push({
  productId: `usdref:${products.length + 1}`,
  issuer, name: fund, shareClass: cls, ticker: ticker || null,
  assetClass: type,
  denomination: 'USD',
  referenceBacking: 'USD cash / U.S. Treasury / eligible government money-market assets as disclosed by issuer',
  status: 'reference-cataloged',
  custodyStatus: 'not-held-by-Bonds-Bank',
  reserveEligible: false,
  reserveEligibilityRule: 'Must be independently acquired, custodied, valued, and verified before any BBUSD reserve credit is recognized.',
  source
});

const SEC='https://www.sec.gov';
const SSGA='https://www.ssga.com';
const productsData = [
// State Street: 38 verified classes from July 31 2026 disclosure
['State Street','State Street Institutional U.S. Government Money Market Fund','Premier Class','GVMXX','government-mm',SSGA],
['State Street','State Street Institutional U.S. Government Money Market Fund','Investment Class','GVVXX','government-mm',SSGA],
['State Street','State Street Institutional U.S. Government Money Market Fund','G Class','SSOXX','government-mm',SSGA],
['State Street','State Street Institutional U.S. Government Money Market Fund','Administration Class','SALXX','government-mm',SSGA],
['State Street','State Street Institutional U.S. Government Money Market Fund','Investor Class','SAMXX','government-mm',SSGA],
['State Street','State Street Institutional U.S. Government Money Market Fund','Institutional Class','SAHXX','government-mm',SSGA],
['State Street','State Street Institutional U.S. Government Money Market Fund','Bancroft Capital Class','VTGXX','government-mm',SSGA],
['State Street','State Street Institutional U.S. Government Money Market Fund','Cabrera Capital Markets Class','CAHXX','government-mm',SSGA],
['State Street','State Street Institutional U.S. Government Money Market Fund','Opportunity Class','OPGXX','government-mm',SSGA],
['State Street','State Street Institutional U.S. Government Money Market Fund','Blaylock Van Class','BUYXX','government-mm',SSGA],
['State Street','State Street Institutional U.S. Government Money Market Fund','Select Class','GVSXX','government-mm',SSGA],
['State Street','State Street Institutional U.S. Government Money Market Fund','Trust Class','GVBXX','government-mm',SSGA],
['State Street','State Street Institutional U.S. Government Money Market Fund','Mercury Class','MRGXX','government-mm',SSGA],
['State Street','State Street Institutional Treasury Money Market Fund','Premier Class','TRIXX','treasury-mm',SSGA],
['State Street','State Street Institutional Treasury Money Market Fund','Investment Class','TRVXX','treasury-mm',SSGA],
['State Street','State Street Institutional Treasury Money Market Fund','Institutional Class','SSJXX','treasury-mm',SSGA],
['State Street','State Street Institutional Treasury Money Market Fund','Investor Class','SSNXX','treasury-mm',SSGA],
['State Street','State Street Institutional Treasury Money Market Fund','Administration Class','SSKXX','treasury-mm',SSGA],
['State Street','State Street Institutional Treasury Money Market Fund','Bancroft Capital Class','VTTXX','treasury-mm',SSGA],
['State Street','State Street Institutional Treasury Money Market Fund','Cabrera Capital Markets Class','CSJXX','treasury-mm',SSGA],
['State Street','State Street Institutional Treasury Money Market Fund','Opportunity Class','OPRXX','treasury-mm',SSGA],
['State Street','State Street Institutional Treasury Plus Money Market Fund','Premier Class','TPIXX','treasury-plus-mm',SSGA],
['State Street','State Street Institutional Treasury Plus Money Market Fund','Investment Class','TPVXX','treasury-plus-mm',SSGA],
['State Street','State Street Institutional Treasury Plus Money Market Fund','Trust Class','TPLXX','treasury-plus-mm',SSGA],
['State Street','State Street Institutional Treasury Plus Money Market Fund','Institutional Class','SAJXX','treasury-plus-mm',SSGA],
['State Street','State Street Institutional Treasury Plus Money Market Fund','Investor Class','SAEXX','treasury-plus-mm',SSGA],
['State Street','State Street Institutional Treasury Plus Money Market Fund','Administration Class','SSQXX','treasury-plus-mm',SSGA],
['State Street','State Street Institutional Treasury Plus Money Market Fund','Bancroft Capital Class','VTLXX','treasury-plus-mm',SSGA],
['State Street','State Street Institutional Treasury Plus Money Market Fund','Cabrera Capital Market Class','CAJXX','treasury-plus-mm',SSGA],
['State Street','State Street Institutional Treasury Plus Money Market Fund','Opportunity Class','OPTXX','treasury-plus-mm',SSGA],
['State Street','State Street Institutional Treasury Plus Money Market Fund','Blaylock Van Class','BVYXX','treasury-plus-mm',SSGA],
['State Street','State Street Prime Retail Reserves Money Market Fund','Cash Management Class','PCMXX','prime-mm',SSGA],
['State Street','State Street Prime Retail Reserves Money Market Fund','Capital Class','PCPXX','prime-mm',SSGA],
['State Street','State Street Prime Retail Reserves Money Market Fund','Agency Class','PRAXX','prime-mm',SSGA],
['State Street','State Street Prime Retail Reserves Money Market Fund','Advisory Class','PRDXX','prime-mm',SSGA],
['State Street','State Street Prime Retail Reserves Money Market Fund','Advantage Class','PAVXX','prime-mm',SSGA],
['State Street','State Street Stablecoin Reserves Money Market Fund','Preferred Class','SSRXX','stablecoin-reserve-mm',SSGA],
['State Street','State Street Stablecoin Reserves Money Market Fund','Capital Class','SSCXX','stablecoin-reserve-mm',SSGA],
// Tokenized MMFs identified by SEC
['360 Funds','M3SIXTY Onchain U.S. Government Money Market Fund','Onchain','MCGXX','tokenized-government-mm',`${SEC}/files/investment/mmf-statistics-05-2026.pdf`],
['BNY Dreyfus','BNY Dreyfus Treasury Securities Cash Management','Token-Enabled Shares','TKNXX','tokenized-treasury-mm','https://www.bny.com/investments/us/en/intermediary/products/mm/fund/dreyfus-treasury-securities-cash-management.shareclass.Token-Enabled-Shares.html'],
['Fidelity','Fidelity Treasury Digital Fund','Onchain','FYOXX','tokenized-treasury-mm',`${SEC}/files/investment/mmf-statistics-05-2026.pdf`],
['Franklin Templeton','Franklin Onchain U.S. Government Money Fund','Onchain','FOBXX','tokenized-government-mm',`${SEC}/files/investment/mmf-statistics-05-2026.pdf`],
['JPMorgan','JPMorgan OnChain Liquidity-Token Money Market Fund','Token Class','JTTXX','tokenized-government-mm',`${SEC}/files/investment/mmf-statistics-05-2026.pdf`],
['WisdomTree','WisdomTree Treasury Money Market Digital Fund','Digital Fund','WTGXX','tokenized-treasury-mm',`${SEC}/files/investment/mmf-statistics-05-2026.pdf`],
// JPMorgan
['JPMorgan','JPMorgan U.S. Government Money Market Fund','Service','SJGXX','government-mm',`${SEC}/Archives/edgar/data/763852/000119312526279105/d107092d497k.htm`],
['JPMorgan','JPMorgan U.S. Government Money Market Fund','Investor','JGMXX','government-mm',`${SEC}/Archives/edgar/data/763852/000119312526279136/d354390d497k.htm`],
['JPMorgan','JPMorgan U.S. Government Money Market Fund','Academy','JGAXX','government-mm',`${SEC}/Archives/edgar/data/763852/000119312526279020/d146703d497k.htm`],
['JPMorgan','JPMorgan 100% U.S. Treasury Securities Money Market Fund','Agency','VPIXX','treasury-mm',`${SEC}/Archives/edgar/data/1659326/000119312526277786/d54994d485bpos.htm`],
['JPMorgan','JPMorgan Federal Money Market Fund','Agency','VFIXX','government-mm',`${SEC}/Archives/edgar/data/1659326/000119312526277786/d54994d485bpos.htm`],
['JPMorgan','JPMorgan U.S. Government Money Market Fund','Agency','OGAXX','government-mm',`${SEC}/Archives/edgar/data/1659326/000119312526277786/d54994d485bpos.htm`],
['JPMorgan','JPMorgan U.S. Treasury Plus Money Market Fund','Agency','AJTXX','treasury-plus-mm',`${SEC}/Archives/edgar/data/1659326/000119312526277786/d54994d485bpos.htm`],
['JPMorgan','JPMorgan 100% U.S. Treasury Securities Money Market Fund','Capital','CJTXX','treasury-mm',`${SEC}/Archives/edgar/data/1659326/000119312526277786/d54994d485bpos.htm`],
['JPMorgan','JPMorgan Federal Money Market Fund','Capital','JFCXX','government-mm',`${SEC}/Archives/edgar/data/1659326/000119312526277786/d54994d485bpos.htm`],
['JPMorgan','JPMorgan U.S. Government Money Market Fund','Capital','OGVXX','government-mm',`${SEC}/Archives/edgar/data/1659326/000119312526277786/d54994d485bpos.htm`],
['JPMorgan','JPMorgan U.S. Treasury Plus Money Market Fund','Capital','JTCXX','treasury-plus-mm',`${SEC}/Archives/edgar/data/1659326/000119312526277786/d54994d485bpos.htm`],
// PIMCO
['PIMCO','PIMCO Government Money Market Fund','Institutional','PGYXX','government-mm',`${SEC}/Archives/edgar/data/810893/000119312526321580/d156477d497k.htm`],
['PIMCO','PIMCO Government Money Market Fund','I-2','PGPXX','government-mm',`${SEC}/Archives/edgar/data/810893/000119312526321580/d156477d497k.htm`],
['PIMCO','PIMCO Government Money Market Fund','M','PGFXX','government-mm',`${SEC}/Archives/edgar/data/810893/000119312526321580/d156477d497k.htm`],
['PIMCO','PIMCO Government Money Market Fund','Administrative','PGOXX','government-mm',`${SEC}/Archives/edgar/data/810893/000119312526321580/d156477d497k.htm`],
['PIMCO','PIMCO Government Money Market Fund','A','AMAXX','government-mm',`${SEC}/Archives/edgar/data/810893/000119312526321580/d156477d497k.htm`],
['PIMCO','PIMCO Government Money Market Fund','C','AMGXX','government-mm',`${SEC}/Archives/edgar/data/810893/000119312526321580/d156477d497k.htm`],
// Fidelity
['Fidelity','Fidelity Government Money Market Fund','Government','SPAXX','government-mm',`${SEC}/Archives/edgar/data/917286/000093369126000219/jnlst497k_38.htm`],
['Fidelity','Fidelity Government Money Market Fund','Daily Money','FZBXX','government-mm',`${SEC}/Archives/edgar/data/917286/000093369126000219/jnlst497k_38.htm`],
['Fidelity','Fidelity Government Money Market Fund','Capital Reserves','FZAXX','government-mm',`${SEC}/Archives/edgar/data/917286/000093369126000219/jnlst497k_38.htm`],
['Fidelity','Fidelity Government Money Market Fund','Advisor M','FZGXX','government-mm',`${SEC}/Archives/edgar/data/917286/000093369126000219/jnlst497k_38.htm`],
['Fidelity','Fidelity Government Money Market Fund','S','FZSXX','government-mm',`${SEC}/Archives/edgar/data/917286/000093369126000219/jnlst497k_38.htm`],
// HSBC
['HSBC','HSBC US Government Money Market Fund','A','HGDXX','government-mm','https://app.personalfund.com/fund-directory/H/BAY.html'],
['HSBC','HSBC US Government Money Market Fund','I','HGIXX','government-mm','https://app.personalfund.com/fund-directory/H/BAY.html'],
['HSBC','HSBC US Government Money Market Fund','P','HGPXX','government-mm','https://app.personalfund.com/fund-directory/H/BAY.html'],
['HSBC','HSBC US Government Money Market Fund','Y','RGYXX','government-mm','https://app.personalfund.com/fund-directory/H/BAY.html'],
['HSBC','HSBC US Government Money Market Fund','Intermediary','HGGXX','government-mm','https://app.personalfund.com/fund-directory/H/BAY.html'],
['HSBC','HSBC US Government Money Market Fund','Intermediary Service','HGFXX','government-mm','https://app.personalfund.com/fund-directory/H/BAY.html'],
// Schwab
['Schwab','Schwab Government Money Fund','Investor','SNVXX','government-mm','https://www.schwab.com/money-market-funds'],
['Schwab','Schwab Government Money Fund','Ultra','SGUXX','government-mm','https://www.schwab.com/money-market-funds'],
['Schwab','Schwab Treasury Obligations Money Fund','Investor','SNOXX','treasury-mm','https://www.schwab.com/money-market-funds'],
['Schwab','Schwab Treasury Obligations Money Fund','Ultra','SCOXX','treasury-mm','https://www.schwab.com/money-market-funds'],
// Vanguard
['Vanguard','Vanguard Cash Reserves Federal Money Market Fund','Admiral','VMRXX','government-mm',`${SEC}/Archives/edgar/data/106830/000010683026000008/f45672d1.htm`],
['Vanguard','Vanguard Federal Money Market Fund','Investor','VMFXX','government-mm',`${SEC}/Archives/edgar/data/106830/000010683026000008/f45672d1.htm`],
['Vanguard','Vanguard Treasury Money Market Fund','Investor','VUSXX','treasury-mm',`${SEC}/Archives/edgar/data/106830/000010683026000008/f45672d1.htm`],
// Nationwide
['Nationwide','Nationwide Government Money Market Fund','Investor','MIFXX','government-mm',`${SEC}/Archives/edgar/data/1048702/000119312526071625/d90789d497k.htm`],
['Nationwide','Nationwide Government Money Market Fund','Service','NWSXX','government-mm',`${SEC}/Archives/edgar/data/1048702/000119312526071625/d90789d497k.htm`],
['Nationwide','Nationwide Government Money Market Fund','R6','GMIXX','government-mm',`${SEC}/Archives/edgar/data/1048702/000119312526071625/d90789d497k.htm`],
// Allspring
['Allspring','Allspring 100% Treasury Money Market Fund','Institutional','WOTXX','treasury-mm','https://www.allspringglobal.com/investments/fixed-income/mutual-funds/100-treasury-money-market/i/'],
// Rydex
['Rydex','U.S. Government Money Market Fund','Money Market','RYFXX','government-mm',`${SEC}/Archives/edgar/data/899148/000119312526328474/d143897d497k.htm`],
// BNY Dreyfus additional class
['BNY Dreyfus','BNY Dreyfus Treasury Securities Cash Management','Participant Shares','DPRXX','treasury-mm','https://www.bny.com/investments/us/en/intermediary/products/mm/fund/dreyfus-treasury-securities-cash-management.shareclass.Participant-Shares.html'],
// BlackRock government/treasury funds
['BlackRock','BlackRock Select Treasury Based Liquidity Fund','Administration','', 'treasury-mm',`${SEC}/Archives/edgar/data/97098/000119312526214958/d45978d485apos.htm`],
['BlackRock','BlackRock Select Treasury Based Liquidity Fund','Cash Management','', 'treasury-mm',`${SEC}/Archives/edgar/data/97098/000119312526214958/d45978d485apos.htm`],
['BlackRock','BlackRock Treasury Trust Fund','DLT Shares','', 'tokenized-treasury-mm',`${SEC}/Archives/edgar/data/97098/000119312526095522/0001193125-26-095522-index.htm`],
['BlackRock','BlackRock Government Money Market Portfolio','Portfolio','', 'government-mm',`${SEC}/Archives/edgar/data/844779/000119312526214946/d283147d485apos.htm`],
// Goldman Sachs
['Goldman Sachs','Goldman Sachs Financial Square Treasury Obligations Fund','Institutional','FTOXX','treasury-mm',`${SEC}/Archives/edgar/data/822977/000175272425021727/000175272425021727-index.html`],
['Goldman Sachs','Goldman Sachs Financial Square Treasury Obligations Fund','Administration','FGAXX','treasury-mm',`${SEC}/Archives/edgar/data/822977/000175272425021727/000175272425021727-index.html`],
['Goldman Sachs','Goldman Sachs Financial Square Treasury Obligations Fund','Service','FYAXX','treasury-mm',`${SEC}/Archives/edgar/data/822977/000175272425021727/000175272425021727-index.html`],
['Goldman Sachs','Goldman Sachs Financial Square Treasury Obligations Fund','Preferred','GPOXX','treasury-mm',`${SEC}/Archives/edgar/data/822977/000175272425021727/000175272425021727-index.html`],
['Goldman Sachs','Goldman Sachs Financial Square Treasury Obligations Fund','Select','GSOXX','treasury-mm',`${SEC}/Archives/edgar/data/822977/000175272425021727/000175272425021727-index.html`],
['Goldman Sachs','Goldman Sachs Financial Square Treasury Obligations Fund','Capital','GCTXX','treasury-mm',`${SEC}/Archives/edgar/data/822977/000175272425021727/000175272425021727-index.html`],
['Goldman Sachs','Goldman Sachs Financial Square Treasury Obligations Fund','Premier','GTPXX','treasury-mm',`${SEC}/Archives/edgar/data/822977/000175272425021727/000175272425021727-index.html`],
['Goldman Sachs','Goldman Sachs Financial Square Treasury Obligations Fund','Resource','GTRXX','treasury-mm',`${SEC}/Archives/edgar/data/822977/000175272425021727/000175272425021727-index.html`],
['Goldman Sachs','Goldman Sachs Financial Square Treasury Obligations Fund','Cash Management','GTOXX','treasury-mm',`${SEC}/Archives/edgar/data/822977/000175272425021727/000175272425021727-index.html`],
['Goldman Sachs','Goldman Sachs Financial Square Treasury Instruments Fund','Institutional','FTIXX','treasury-mm',`${SEC}/Archives/edgar/data/822977/000119312526129865/000119312526129865-index.htm`],
['Goldman Sachs','Goldman Sachs Financial Square Treasury Instruments Fund','Administration','FRAXX','treasury-mm',`${SEC}/Archives/edgar/data/822977/000119312526129865/000119312526129865-index.htm`],
['Goldman Sachs','Goldman Sachs Financial Square Treasury Instruments Fund','Service','FYSXX','treasury-mm',`${SEC}/Archives/edgar/data/822977/000119312526129865/000119312526129865-index.htm`],
['Goldman Sachs','Goldman Sachs Financial Square Treasury Instruments Fund','Preferred','GPIXX','treasury-mm',`${SEC}/Archives/edgar/data/822977/000119312526129865/000119312526129865-index.htm`],
// Federated
['Federated Hermes','Federated Hermes U.S. Treasury Cash Reserves','Service','TISXX','treasury-mm',`${SEC}/Archives/edgar/data/856517/000162363226000915/ustcrssq450303sumproedg.htm`],
['Federated Hermes','Federated Hermes U.S. Treasury Cash Reserves','Institutional','UTIXX','treasury-mm',`${SEC}/Archives/edgar/data/856517/000119312525271620/000119312525271620-index.htm`],
['Federated Hermes','Federated Hermes U.S. Treasury Cash Reserves','Premier','UTPXX','treasury-mm',`${SEC}/Archives/edgar/data/856517/000119312525271620/000119312525271620-index.htm`],
['Federated Hermes','Federated Hermes U.S. Treasury Cash Reserves','Administrative','UTDXX','treasury-mm',`${SEC}/Archives/edgar/data/856517/000119312525271620/000119312525271620-index.htm`],
['Federated Hermes','Federated Hermes U.S. Treasury Cash Reserves','Advisor','UTVXX','treasury-mm',`${SEC}/Archives/edgar/data/856517/000119312525271620/000119312525271620-index.htm`],
['Federated Hermes','Federated Hermes U.S. Treasury Cash Reserves','Select','UTEXX','treasury-mm',`${SEC}/Archives/edgar/data/856517/000119312525271620/000119312525271620-index.htm`],
['Federated Hermes','Federated Hermes U.S. Treasury Cash Reserves','Cash Reserve','UTRXX','treasury-mm',`${SEC}/Archives/edgar/data/856517/000119312525271620/000119312525271620-index.htm`],
];

for (const row of productsData) add(...row);
if (products.length < 100) throw new Error(`Only ${products.length} products assembled`);
products.length = 100;

const catalog = {
  schemaVersion: '1.0',
  network: '007',
  chainId: 7007,
  catalogPurpose: 'reference catalog of real USD-denominated / USD-government-money-market products for asset integration research',
  generatedAt: new Date().toISOString(),
  productCount: products.length,
  ownershipClaim: 'none',
  reserveClaim: 'none',
  policy: {
    reserveCredit: 'disabled until independent acquisition, custody, valuation and eligibility verification',
    bbUSDBacking: 'Only independently verified eligible reserve assets may increase BBUSD reserve capacity.',
    noAutomaticPurchase: true,
    noAutomaticMint: true
  },
  products
};
fs.writeFileSync('config/usd-backed-products-100.json', JSON.stringify(catalog, null, 2) + '\n');
console.log(`Cataloged ${products.length} products`);
