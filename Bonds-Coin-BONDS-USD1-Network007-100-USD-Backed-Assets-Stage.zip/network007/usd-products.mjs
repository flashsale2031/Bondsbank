import fs from 'node:fs';

export function loadUsdBackedProducts(file = 'config/usd-backed-products-100.json') {
  const catalog = JSON.parse(fs.readFileSync(file, 'utf8'));
  if (catalog.network !== '007' || catalog.chainId !== 7007) throw new Error('invalid Network 007 catalog');
  if (catalog.productCount !== 100 || catalog.products.length !== 100) throw new Error('catalog must contain exactly 100 products');
  const ids = new Set();
  for (const p of catalog.products) {
    if (ids.has(p.productId)) throw new Error(`duplicate product id: ${p.productId}`);
    ids.add(p.productId);
    if (p.denomination !== 'USD') throw new Error(`non-USD product: ${p.productId}`);
    if (p.reserveEligible !== false) throw new Error(`unverified product marked reserve eligible: ${p.productId}`);
  }
  return catalog;
}

export function reserveEligibleProducts(catalog) {
  return catalog.products.filter(p => p.reserveEligible === true && p.custodyStatus === 'verified');
}
