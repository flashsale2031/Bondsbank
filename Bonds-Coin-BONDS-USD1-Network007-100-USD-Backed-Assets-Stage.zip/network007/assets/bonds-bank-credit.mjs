export const BONDS_BANK_CREDIT = {
  assetId: 'bondsbank:007:BBUSD',
  symbol: 'BBUSD',
  name: 'Bonds Bank Tokenized USD Credit',
  chainId: '7007',
  decimals: 6,
  standard: 'permissioned-erc20-equivalent',
  assetClass: 'tokenized-bank-credit',
  issuer: 'Bonds Bank',
  contractReference: 'contracts/BondsBankUSDToken.sol',
  backing: '1:1 verified USD reserve / eligible bank liability',
  mintPolicy: 'verified-deposit-required',
  redemptionPolicy: 'settlement-confirmation-required',
  transferPolicy: 'KYC-whitelist-and-freeze-controls',
  bridgePolicy: 'verified-proof-and-provider-adapter-required'
};

export function registerBondsBankCredit(registry) {
  return registry.registerAsset({
    assetId: BONDS_BANK_CREDIT.assetId,
    chainId: BONDS_BANK_CREDIT.chainId,
    symbol: BONDS_BANK_CREDIT.symbol,
    name: BONDS_BANK_CREDIT.name,
    decimals: BONDS_BANK_CREDIT.decimals,
    standard: BONDS_BANK_CREDIT.standard,
    assetClass: BONDS_BANK_CREDIT.assetClass,
    issuer: BONDS_BANK_CREDIT.issuer,
    backing: BONDS_BANK_CREDIT.backing,
    mintPolicy: BONDS_BANK_CREDIT.mintPolicy,
    redemptionPolicy: BONDS_BANK_CREDIT.redemptionPolicy,
    transferPolicy: BONDS_BANK_CREDIT.transferPolicy,
    bridgePolicy: BONDS_BANK_CREDIT.bridgePolicy,
    status: 'registered'
  });
}
