import { createHash } from 'node:crypto';

const hash = x => createHash('sha256').update(typeof x === 'string' ? x : JSON.stringify(x)).digest('hex');

/** Deterministic policy engine: no autonomous signing or custody. */
export class Network007IntelligenceAdapter {
  constructor({ registry, bridgeRegistry, now = () => Date.now() } = {}) {
    this.registry = registry; this.bridges = bridgeRegistry; this.now = now;
    this.liquidity = new Map(); this.security = new Map(); this.proofPolicies = new Map();
  }
  registerLiquidityPool(pool) {
    if (!pool?.id || !pool.fromAsset || !pool.toAsset || BigInt(pool.capacity || 0) <= 0n) throw new Error('invalid liquidity pool');
    this.liquidity.set(pool.id, { ...pool, capacity: String(pool.capacity), feeBps: Number(pool.feeBps || 0), score: Number(pool.score ?? 50), status: pool.status || 'active' });
    return pool.id;
  }
  registerSecurityProfile(chainId, profile) {
    const p = { finalityScore: 50, proofScore: 50, validatorScore: 50, bridgeScore: 50, ...profile };
    for (const k of Object.keys(p)) if (!Number.isFinite(Number(p[k])) || Number(p[k]) < 0 || Number(p[k]) > 100) throw new Error('invalid security score');
    this.security.set(String(chainId), p); return p;
  }
  registerProofPolicy(chainId, policy) {
    if (!policy?.type) throw new Error('invalid proof policy');
    this.proofPolicies.set(String(chainId), { minScore: 70, maxAgeMs: 120000, ...policy }); return this.proofPolicies.get(String(chainId));
  }
  verifyProof({ chainId, proof, observedAt = this.now() }) {
    const policy = this.proofPolicies.get(String(chainId));
    if (!policy || !proof?.digest || !proof?.issuedAt) return { ok: false, reason: 'proof policy or proof missing' };
    if (observedAt - Number(proof.issuedAt) > Number(policy.maxAgeMs)) return { ok: false, reason: 'proof stale' };
    const securityScore = this.security.get(String(chainId))?.proofScore ?? 0;
    if (securityScore < Number(policy.minScore)) return { ok: false, reason: 'proof security score below policy' };
    const expected = hash({ chainId: String(chainId), payload: proof.payload, issuedAt: proof.issuedAt, nonce: proof.nonce });
    if (expected !== proof.digest) return { ok: false, reason: 'proof digest mismatch' };
    return { ok: true, securityScore };
  }
  planLiquidity({ fromAsset, toAsset, amount }) {
    const n = BigInt(amount); if (n <= 0n) throw new Error('amount must be positive');
    const candidates = [...this.liquidity.values()].filter(p => p.status === 'active' && p.fromAsset === fromAsset && p.toAsset === toAsset && BigInt(p.capacity) >= n);
    if (!candidates.length) throw new Error('no sufficient verified liquidity');
    candidates.sort((a,b) => (b.score - a.score) || (a.feeBps - b.feeBps));
    const p = candidates[0]; return { poolId:p.id, amount:String(n), feeBps:p.feeBps, score:p.score, routeDigest:hash({pool:p.id,fromAsset,toAsset,amount:String(n)}) };
  }
  assessRoute({ fromAsset, toAsset, amount, sourceChainId, destinationChainId, bridgeId }) {
    const src = this.security.get(String(sourceChainId)) || {};
    const dst = this.security.get(String(destinationChainId)) || {};
    const bridge = this.bridges?.get(bridgeId);
    if (!bridge) return { approved:false, risk:'critical', reasons:['bridge adapter unavailable'] };
    const liquidity = this.planLiquidity({ fromAsset, toAsset, amount });
    const score = Math.round((Number(src.finalityScore||0)+Number(dst.finalityScore||0)+Number(src.bridgeScore||0)+Number(dst.bridgeScore||0)+liquidity.score)/5);
    const approved = score >= 70;
    return { approved, score, risk: score >= 85 ? 'low' : score >= 70 ? 'moderate' : 'high', liquidity, reasons: approved ? [] : ['route score below policy threshold'] };
  }
}
