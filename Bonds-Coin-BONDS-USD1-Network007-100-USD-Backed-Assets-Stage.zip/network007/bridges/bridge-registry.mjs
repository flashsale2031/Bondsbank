export class BridgeRegistry007{
 constructor(registry){this.registry=registry;this.adapters=new Map();}
 register(adapter){if(!adapter?.id||typeof adapter.lock!=='function'||typeof adapter.release!=='function')throw new Error('invalid bridge adapter');this.adapters.set(adapter.id,adapter);return adapter.id;}
 get(id){const a=this.adapters.get(id);if(!a)throw new Error('bridge adapter not found');return a;}
 async bridge(req){const a=this.get(req.adapterId);return a.bridge(req);}
}
export function createBridgeAdapter({id,sourceChainId,destinationChainId,verifyProof=async()=>true}){const locks=new Set(),releases=new Set();return {id,sourceChainId,destinationChainId,async lock(req){if(locks.has(req.id))throw new Error('duplicate lock');locks.add(req.id);return {id:req.id,status:'locked',sourceChainId,destinationChainId,proof:`external:${req.id}`};},async release(req){if(releases.has(req.id))throw new Error('duplicate release');if(!await verifyProof(req.proof))throw new Error('invalid bridge proof');releases.add(req.id);return {id:req.id,status:'released',destinationChainId};},async bridge(req){const l=await this.lock(req);return this.release(l);}};}
