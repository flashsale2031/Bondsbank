import { randomUUID } from 'node:crypto';
export class UnifiedTokenConverter007{
 constructor(registry,bridgeRegistry){this.registry=registry;this.bridges=bridgeRegistry;this.adapters=new Map();}
 registerAdapter(assetId,adapter){if(!adapter?.quote||!adapter?.execute)throw new Error('invalid converter adapter');this.adapters.set(assetId,adapter);}
 quote({fromAsset,toAsset,amount}){const from=this.registry.assets.get(fromAsset),to=this.registry.assets.get(toAsset);if(!from||!to)throw new Error('asset not registered');if(fromAsset===toAsset)return this.registry.quote(fromAsset,toAsset,amount,1,0);const route=this.registry.route(fromAsset,toAsset);if(!route)throw new Error('no verified conversion route');const adapter=this.adapters.get(fromAsset);if(!adapter)throw new Error('no source asset adapter');return adapter.quote({quoteId:randomUUID(),from,to,amount,route});}
 async convert(params){const q=await this.quote(params);if(q.expiresAt&&Date.now()>q.expiresAt)throw new Error('quote expired');const adapter=this.adapters.get(params.fromAsset);const result=await adapter.execute(q,params);return {network:'007',quote:q,result};}
}
