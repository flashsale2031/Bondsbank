import { createHash } from 'node:crypto';
export const proofDigest = ({ chainId, payload, issuedAt, nonce }) => createHash('sha256').update(JSON.stringify({chainId:String(chainId),payload,issuedAt,nonce})).digest('hex');
export function createDeterministicProof({ chainId, payload, issuedAt = Date.now(), nonce }) {
  if (!nonce) throw new Error('nonce required');
  return { chainId:String(chainId), payload, issuedAt, nonce, digest:proofDigest({chainId,payload,issuedAt,nonce}) };
}
