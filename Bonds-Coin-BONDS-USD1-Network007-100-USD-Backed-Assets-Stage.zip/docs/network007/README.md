# Bonds Bank Credit on Network 007

Network 007 registers **BBUSD (Bonds Bank Tokenized USD Credit)** as a permissioned tokenized-bank-credit asset.

- Asset ID: `bondsbank:007:BBUSD`
- Chain ID: `7007`
- Decimals: `6`
- Contract foundation: `contracts/BondsBankUSDToken.sol`
- Minting: verified bank/depository deposit evidence required
- Redemption: confirmed external USD settlement required before burn
- Transfers: KYC allowlist and freeze controls
- Bridging: verified proof, bridge, liquidity and security adapters required

Registration does not create reserves, bank liabilities, custody relationships, or a regulatory authorization. Production minting remains gated on real provider evidence.
