# Network 007 — 100 USD-Backed Product Reference Catalog

Network 007 now contains a catalog of 100 real, publicly documented USD-denominated cash-management products, including U.S. government/Treasury money-market funds and tokenized money-market products.

## Important status

These are **reference assets, not assets owned by Bonds Bank**. The catalog deliberately sets `reserveEligible: false` and `custodyStatus: not-held-by-Bonds-Bank` for every entry. Listing a product does not establish possession, reserve value, legal eligibility, or a claim on the issuer.

Before any product can support BBUSD reserve capacity, Bonds Bank must independently establish:

1. lawful acquisition and beneficial ownership;
2. qualified custody;
3. current valuation/NAV and liquidity;
4. issuer/product eligibility under the applicable reserve framework;
5. independent reconciliation to the custody record; and
6. legal/compliance approval for its use as a reserve asset.

This is particularly important because money-market funds are investments and are not themselves bank deposits; SEC materials also state that such funds are not FDIC insured and may lose value. The reserve engine therefore remains fail-closed.

## Catalog sources

The catalog is based on current public issuer/SEC materials, including the SEC's tokenized-money-market-fund table, State Street's July 2026 fund-class disclosure, JPMorgan prospectuses, PIMCO's August 2026 prospectus, Fidelity's June 2026 prospectus, Schwab's money-market-fund listing, Vanguard's SEC filing, Nationwide's SEC prospectus, Allspring's product page, BNY Dreyfus fund pages, Goldman Sachs SEC filings, and Federated Hermes SEC filings.

The catalog is intended for **integration and due-diligence tracking**, not as an investment recommendation.
