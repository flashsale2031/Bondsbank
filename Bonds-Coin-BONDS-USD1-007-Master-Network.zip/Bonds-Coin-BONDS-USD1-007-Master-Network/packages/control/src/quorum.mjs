import { createHash, generateKeyPairSync, sign, verify } from "node:crypto";

export function createSigner() {
  return generateKeyPairSync("ed25519", { publicKeyEncoding: {type:"spki", format:"pem"}, privateKeyEncoding: {type:"pkcs8", format:"pem"} });
}
export function approvalDigest(action) {
  return createHash("sha256").update(JSON.stringify(action)).digest("hex");
}
export function signApproval(action, signerId, privateKey) {
  const digest = approvalDigest(action);
  return { signerId, digest, signature: sign(null, Buffer.from(digest), privateKey).toString("base64url") };
}
export function verifyApproval(action, approval, publicKey) {
  return approval.digest === approvalDigest(action) && verify(null, Buffer.from(approval.digest), publicKey, Buffer.from(approval.signature, "base64url"));
}
export function assertQuorum(action, approvals, signerRegistry, threshold) {
  const valid = new Set();
  for (const approval of approvals) {
    const signer = signerRegistry.get(approval.signerId);
    if (signer && verifyApproval(action, approval, signer.publicKey)) valid.add(approval.signerId);
  }
  if (valid.size < threshold) throw new Error(`quorum not met: ${valid.size}/${threshold}`);
  return [...valid];
}
