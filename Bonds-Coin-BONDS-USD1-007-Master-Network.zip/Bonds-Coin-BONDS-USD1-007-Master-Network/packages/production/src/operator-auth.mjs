import { createHash, verify, createPublicKey } from 'node:crypto';
export function requestDigest(req){ return createHash('sha256').update(JSON.stringify({method:req.method,path:req.path,body:req.body||null,timestamp:req.timestamp})).digest('hex'); }
export function verifyOperatorRequest(req, publicKeyPem){
  if(!req?.signature || !Number.isSafeInteger(req.timestamp)) return false;
  if(Math.abs(Date.now()-req.timestamp)>120000) return false;
  try{return verify(null,Buffer.from(requestDigest(req)),createPublicKey(publicKeyPem),Buffer.from(req.signature,'base64url'));}catch{return false;}
}
