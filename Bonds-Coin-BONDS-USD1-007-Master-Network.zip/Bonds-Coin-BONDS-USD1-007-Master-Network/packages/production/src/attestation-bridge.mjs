export { verifyAttestation } from '../../issuer/src/attestation.mjs';
