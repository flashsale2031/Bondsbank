import fs from 'node:fs';
import path from 'node:path';

export class DurableReplayGuard {
  constructor(dir,name='replay'){ this.file=path.join(dir,`${name}.json`); fs.mkdirSync(dir,{recursive:true}); this.state=fs.existsSync(this.file)?JSON.parse(fs.readFileSync(this.file,'utf8')):{ids:{}}; }
  save(){ const tmp=this.file+'.tmp'; fs.writeFileSync(tmp,JSON.stringify(this.state),{mode:0o600}); fs.renameSync(tmp,this.file); }
  claim(id){ if(!id) throw new Error('replay id required'); if(this.state.ids[id]) throw new Error('replay detected'); this.state.ids[id]=Date.now(); this.save(); return true; }
  has(id){ return Boolean(this.state.ids[id]); }
}
