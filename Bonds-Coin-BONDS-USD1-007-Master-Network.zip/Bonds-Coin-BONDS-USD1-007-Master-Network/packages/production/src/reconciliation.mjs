import { reconcileReserve } from '../../issuer/src/reserve.mjs';
export function productionReconciliation({issuedBondsAtomic, attestation, hairCutBps=0n}, now=Date.now()){
  return reconcileReserve({issuedBondsAtomic:BigInt(issuedBondsAtomic),attestation,hairCutBps}, now);
}
