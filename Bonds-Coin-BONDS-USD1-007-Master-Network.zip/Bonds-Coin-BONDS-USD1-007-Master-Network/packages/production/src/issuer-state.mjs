import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { attestationDigest, assertMintCovered } from '../../issuer/src/reserve.mjs';
import { validateAttestation, verifyAttestation } from '../../issuer/src/attestation.mjs';
import { assertQuorum } from '../../control/src/quorum.mjs';

export const ActionStatus = Object.freeze({ PROPOSED:'proposed', APPROVED:'approved', EXECUTED:'executed', REJECTED:'rejected' });

export function actionDigest(action) {
  return createHash('sha256').update(JSON.stringify(action)).digest('hex');
}

export class IssuerState {
  constructor({dir, issuerAddress, quorumThreshold, signerRegistry}) {
    this.dir = dir;
    this.issuerAddress = issuerAddress;
    this.quorumThreshold = quorumThreshold;
    this.signerRegistry = signerRegistry;
    fs.mkdirSync(dir, {recursive:true});
    this.file = path.join(dir, 'issuer-state.json');
    this.auditFile = path.join(dir, 'issuer-audit.jsonl');
    this.state = fs.existsSync(this.file) ? JSON.parse(fs.readFileSync(this.file,'utf8')) : {activeAttestation:null, actions:{}};
  }
  save() { fs.writeFileSync(this.file, JSON.stringify(this.state, null, 2), {mode:0o600}); }
  audit(event, details={}) { fs.appendFileSync(this.auditFile, JSON.stringify({at:Date.now(),event,...details})+'\n',{mode:0o600}); }
  registerAttestation(attestation, signature, publicKey, now=Date.now()) {
    validateAttestation(attestation, now);
    if (!verifyAttestation(attestation, signature, publicKey)) throw new Error('invalid reserve attestation signature');
    this.state.activeAttestation = {...attestation, signature, publicKey, verified:true};
    this.save(); this.audit('reserve_attestation_registered',{digest:attestationDigest(attestation)});
    return this.state.activeAttestation;
  }
  proposeMint({id, to, amountBondsAtomic, issuedBondsAtomic='0', feeAtomic='0', attestationDigest:ad}) {
    const amount = BigInt(amountBondsAtomic);
    if (!id || !to || amount<=0n) throw new Error('invalid mint proposal');
    if (!this.state.activeAttestation || attestationDigest(this.state.activeAttestation)!==ad) throw new Error('active attestation digest mismatch');
    assertMintCovered({issuedBondsAtomic:BigInt(issuedBondsAtomic), attestation:this.state.activeAttestation}, amount);
    const action = {id, type:'mint', to, amountBondsAtomic:amount.toString(), feeAtomic:String(feeAtomic), attestationDigest:ad};
    this.state.actions[id]={action,status:ActionStatus.PROPOSED,approvals:[]}; this.save(); this.audit('mint_proposed',{id,digest:actionDigest(action)}); return this.state.actions[id];
  }
  approveMint(id, approvals) {
    const rec=this.state.actions[id]; if(!rec) throw new Error('action not found');
    if(rec.status!==ActionStatus.PROPOSED && rec.status!==ActionStatus.APPROVED) throw new Error('action is not approvable');
    const valid=assertQuorum(rec.action, approvals, this.signerRegistry, this.quorumThreshold);
    rec.approvals=approvals; rec.validSignerIds=valid; rec.status=ActionStatus.APPROVED; rec.approvedAt=Date.now(); this.save(); this.audit('mint_approved',{id,signers:valid}); return rec;
  }
  markExecuted(id, txId) {
    const rec=this.state.actions[id]; if(!rec || rec.status!==ActionStatus.APPROVED) throw new Error('action must be approved');
    if(!txId) throw new Error('tx id required'); rec.status=ActionStatus.EXECUTED; rec.txId=txId; rec.executedAt=Date.now(); this.save(); this.audit('mint_executed',{id,txId}); return rec;
  }
}

