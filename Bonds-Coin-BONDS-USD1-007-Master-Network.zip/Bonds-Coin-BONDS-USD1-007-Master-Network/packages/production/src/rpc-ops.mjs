import crypto from 'node:crypto';

export class RateLimiter {
  constructor({windowMs=60_000, max=120}={}) { this.windowMs=windowMs; this.max=max; this.buckets=new Map(); }
  allow(key, now=Date.now()) {
    const b=this.buckets.get(key);
    if(!b || now-b.start>=this.windowMs) { this.buckets.set(key,{start:now,count:1}); return true; }
    if(b.count>=this.max) return false;
    b.count++; return true;
  }
}

export function bearerAuthorized(req, expected) {
  if(!expected) return false;
  const got=String(req.headers.authorization||'');
  const prefix='Bearer ';
  if(!got.startsWith(prefix)) return false;
  const a=Buffer.from(got.slice(prefix.length)); const b=Buffer.from(expected);
  return a.length===b.length && crypto.timingSafeEqual(a,b);
}

export function requestId() { return crypto.randomUUID(); }

export function metricsSnapshot(metrics) {
  return {
    requests_total: metrics.requests,
    requests_rejected_total: metrics.rejected,
    errors_total: metrics.errors,
    started_at: metrics.startedAt,
    uptime_seconds: Math.floor((Date.now()-metrics.startedAt)/1000)
  };
}
