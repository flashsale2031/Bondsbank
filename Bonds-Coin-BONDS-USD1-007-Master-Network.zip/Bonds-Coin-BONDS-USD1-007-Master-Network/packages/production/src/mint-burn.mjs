import { randomUUID } from 'node:crypto';
import { RedemptionBook } from '../../settlement/src/redemption.mjs';

export class MintBurnController {
  constructor({issuerAddress}){ this.issuerAddress=issuerAddress; this.redemptions=new RedemptionBook({issuerAddress}); this.burns=new Map(); }
  createRedemption(input){ return this.redemptions.create(input); }
  approveRedemption(id){ return this.redemptions.approve(id); }
  recordUsdSettlement(id, settlement){
    const r=this.redemptions.get(id); if(r.status!=='approved') throw new Error('redemption must be approved');
    if(BigInt(settlement.amountUsdAtomic)!==BigInt(r.amountBondsAtomic)/100n) throw new Error('USD settlement amount does not match BONDS amount');
    r.usdSettlementId=settlement.id; r.usdSettledAt=Date.now(); return {...r};
  }
  authorizeBurn(id){
    const r=this.redemptions.get(id); if(r.status!=='approved' || !r.usdSettlementId) throw new Error('USD settlement must be recorded before burn');
    const burn={id:randomUUID(),redemptionId:id,to:this.issuerAddress,amountBondsAtomic:String(r.amountBondsAtomic),status:'authorized',createdAt:Date.now()}; this.burns.set(burn.id,burn); return {...burn};
  }
  markBurnExecuted(id,txId){ const b=this.burns.get(id); if(!b) throw new Error('burn not found'); if(b.status!=='authorized') throw new Error('burn not authorized'); b.status='executed'; b.txId=txId; b.executedAt=Date.now(); this.redemptions.settled=this.redemptions.settled||new Set(); this.redemptions.settled.add(b.redemptionId); return {...b}; }
}
