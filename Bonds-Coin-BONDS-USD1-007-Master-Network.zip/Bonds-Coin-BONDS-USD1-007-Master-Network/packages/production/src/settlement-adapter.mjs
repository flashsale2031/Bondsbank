import { createHash, sign, verify, createPrivateKey, createPublicKey } from 'node:crypto';

export function settlementDigest(message){
  return createHash('sha256').update(JSON.stringify({id:message.id,amountUsdAtomic:String(message.amountUsdAtomic),destination:message.destination,kind:message.kind,createdAt:message.createdAt})).digest('hex');
}

export function signSettlement(message, privateKey){
  return sign(null,Buffer.from(settlementDigest(message)),createPrivateKey(privateKey)).toString('base64url');
}

export function verifySettlement(message, signature, publicKey){
  return verify(null,Buffer.from(settlementDigest(message)),createPublicKey(publicKey),Buffer.from(signature,'base64url'));
}

export class SettlementAdapter {
  constructor({provider, publicKey}){ if(!provider||!publicKey) throw new Error('settlement provider identity required'); this.provider=provider; this.publicKey=publicKey; this.seen=new Set(); }
  accept(message, signature){
    if(!message?.id || !signature) throw new Error('signed settlement confirmation required');
    if(this.seen.has(message.id)) throw new Error('settlement replay detected');
    if(!verifySettlement(message,signature,this.publicKey)) throw new Error('invalid settlement signature');
    if(message.kind!=='usd-payout') throw new Error('unsupported settlement kind');
    if(BigInt(message.amountUsdAtomic)<=0n) throw new Error('invalid settlement amount');
    this.seen.add(message.id); return {...message,provider:this.provider,signature};
  }
}
