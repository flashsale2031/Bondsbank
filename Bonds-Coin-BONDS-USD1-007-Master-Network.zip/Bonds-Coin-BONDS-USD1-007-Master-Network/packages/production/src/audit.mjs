import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';

export class AuditLog {
  constructor(dir){ this.file=path.join(dir,'audit.jsonl'); fs.mkdirSync(dir,{recursive:true}); }
  append(event, data={}){
    const prev=this.lastHash();
    const entry={at:Date.now(),event,data,previousHash:prev};
    const hash=createHash('sha256').update(JSON.stringify(entry)).digest('hex');
    const row={...entry,hash}; fs.appendFileSync(this.file,JSON.stringify(row)+'\n',{mode:0o600}); return row;
  }
  lastHash(){
    if(!fs.existsSync(this.file)) return '0'.repeat(64);
    const lines=fs.readFileSync(this.file,'utf8').trim().split('\n').filter(Boolean); if(!lines.length) return '0'.repeat(64); return JSON.parse(lines.at(-1)).hash;
  }
  verify(){
    if(!fs.existsSync(this.file)) return {valid:true,count:0};
    const raw=fs.readFileSync(this.file,'utf8').trim().split('\n').filter(Boolean); let rows; try { rows=raw.map(JSON.parse); } catch { return {valid:false,count:raw.length}; } let prev='0'.repeat(64);
    for(const r of rows){ const {hash,...entry}=r; if(entry.previousHash!==prev || createHash('sha256').update(JSON.stringify(entry)).digest('hex')!==hash) return {valid:false,count:rows.length}; prev=hash; }
    return {valid:true,count:rows.length,tip:prev};
  }
}
