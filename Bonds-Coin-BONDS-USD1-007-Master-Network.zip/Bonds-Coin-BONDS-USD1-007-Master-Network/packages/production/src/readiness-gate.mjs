export function evaluateProductionReadiness({config, reserveValid, custodyConfigured, keysAudited, externalAuditPassed, testnetPassed}){
  const blockers=[];
  if(!config?.issuerAddress || config.issuerAddress.startsWith('REPLACE_')) blockers.push('audited issuer address not configured');
  if(!reserveValid) blockers.push('current reserve evidence not verified');
  if(!custodyConfigured) blockers.push('independent USD custody not configured');
  if(!keysAudited) blockers.push('issuer key infrastructure not audited');
  if(!externalAuditPassed) blockers.push('independent protocol/security audit not passed');
  if(!testnetPassed) blockers.push('required long-duration/adversarial testnet evidence missing');
  return {ready:blockers.length===0,blockers};
}
