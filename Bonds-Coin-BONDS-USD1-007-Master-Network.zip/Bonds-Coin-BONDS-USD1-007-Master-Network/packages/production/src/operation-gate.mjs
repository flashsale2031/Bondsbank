import fs from 'node:fs';
import path from 'node:path';

export class OperationGate {
  constructor(dir){ this.file=path.join(dir,'operation-gate.json'); fs.mkdirSync(dir,{recursive:true}); this.state=fs.existsSync(this.file)?JSON.parse(fs.readFileSync(this.file,'utf8')):{paused:false,reason:null,updatedAt:null}; }
  save(){ const tmp=this.file+'.tmp'; fs.writeFileSync(tmp,JSON.stringify(this.state,null,2),{mode:0o600}); fs.renameSync(tmp,this.file); }
  pause(reason){ if(!reason) throw new Error('pause reason required'); this.state={paused:true,reason,updatedAt:Date.now()}; this.save(); return {...this.state}; }
  resume(){ this.state={paused:false,reason:null,updatedAt:Date.now()}; this.save(); return {...this.state}; }
  assertOpen(){ if(this.state.paused) throw new Error(`production operations paused: ${this.state.reason}`); return true; }
  status(){ return {...this.state}; }
}
