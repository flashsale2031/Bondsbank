import fs from 'node:fs';
import path from 'node:path';
import { createHash, createPublicKey, verify } from 'node:crypto';

export class KeyRegistry {
  constructor(dir){ this.dir=dir; this.file=path.join(dir,'keys.json'); fs.mkdirSync(dir,{recursive:true}); this.state=fs.existsSync(this.file)?JSON.parse(fs.readFileSync(this.file,'utf8')):{version:1,keys:{}}; }
  save(){ const tmp=this.file+'.tmp'; fs.writeFileSync(tmp,JSON.stringify(this.state,null,2),{mode:0o600}); fs.renameSync(tmp,this.file); }
  add({id,publicKeyPem,role,status='active'}){ if(!id||!publicKeyPem||!role) throw new Error('key id, public key, and role required'); if(this.state.keys[id]) throw new Error('key already exists'); createPublicKey(publicKeyPem); this.state.keys[id]={id,publicKeyPem,role,status,createdAt:Date.now()}; this.save(); return this.state.keys[id]; }
  rotate(id,{replacementId,signature}){ const old=this.state.keys[id], replacement=this.state.keys[replacementId]; if(!old||!replacement) throw new Error('rotation key not found'); if(old.status!=='active'||replacement.status!=='active') throw new Error('rotation requires active keys'); const payload=createHash('sha256').update(JSON.stringify({id,replacementId,createdAt:old.createdAt})).digest(); if(!verify(null,payload,createPublicKey(old.publicKeyPem),Buffer.from(signature,'base64url'))) throw new Error('invalid rotation signature'); old.status='retired'; old.retiredAt=Date.now(); replacement.promotedAt=Date.now(); this.save(); return {retired:id,active:replacementId}; }
  active(role){ return Object.values(this.state.keys).filter(k=>k.role===role&&k.status==='active'); }
}
