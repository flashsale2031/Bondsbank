import { createHash, generateKeyPairSync, sign, verify } from "node:crypto";

export const ATTESTATION_VERSION = 1;

export function canonicalAttestationPayload(attestation) {
  return JSON.stringify({
    version: ATTESTATION_VERSION,
    id: attestation.id,
    asOf: attestation.asOf,
    availableUsdAtomic: String(attestation.availableUsdAtomic),
    custodian: attestation.custodian,
    source: attestation.source,
    expiresAt: attestation.expiresAt ?? null
  });
}

export function attestationDigest(attestation) {
  return createHash("sha256").update(canonicalAttestationPayload(attestation)).digest("hex");
}

export function createAttestationKey() {
  return generateKeyPairSync("ed25519", { publicKeyEncoding: {type:"spki", format:"pem"}, privateKeyEncoding: {type:"pkcs8", format:"pem"} });
}

export function signAttestation(attestation, privateKey) {
  return sign(null, Buffer.from(canonicalAttestationPayload(attestation)), privateKey).toString("base64url");
}

export function verifyAttestation(attestation, signature, publicKey) {
  return verify(null, Buffer.from(canonicalAttestationPayload(attestation)), publicKey, Buffer.from(signature, "base64url"));
}

export function validateAttestation(attestation, now = Date.now()) {
  if (!attestation?.id || !attestation?.custodian || !attestation?.source) throw new Error("invalid attestation identity");
  if (!Number.isSafeInteger(attestation.asOf) || attestation.asOf <= 0) throw new Error("invalid attestation timestamp");
  if (BigInt(attestation.availableUsdAtomic) < 0n) throw new Error("reserve cannot be negative");
  if (attestation.expiresAt != null && (!Number.isSafeInteger(attestation.expiresAt) || attestation.expiresAt <= attestation.asOf)) throw new Error("invalid attestation expiry");
  if (attestation.expiresAt != null && attestation.expiresAt <= now) throw new Error("reserve attestation expired");
  return true;
}
