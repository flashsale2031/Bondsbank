import { createHash } from "node:crypto";
import { validateAttestation, attestationDigest } from "./attestation.mjs";

export const USD_DECIMALS = 6n;
export const USD_UNIT = 1_000_000n;
export const BONDS_UNIT = 100_000_000n;

export { attestationDigest };

export function reserveCapacityBondsAtomic(availableUsdAtomic, hairCutBps = 0n) {
  if (availableUsdAtomic < 0n) throw new Error("reserve cannot be negative");
  if (hairCutBps < 0n || hairCutBps > 10_000n) throw new Error("invalid reserve haircut");
  const eligibleUsd = availableUsdAtomic * (10_000n - hairCutBps) / 10_000n;
  return eligibleUsd * BONDS_UNIT / USD_UNIT;
}

export function assertMintCovered(state, mintAmountBondsAtomic, now = Date.now()) {
  if (mintAmountBondsAtomic <= 0n) throw new Error("mint amount must be positive");
  const a = state.attestation;
  if (!a || !a.verified) throw new Error("verified reserve attestation required");
  validateAttestation(a, now);
  const capacity = reserveCapacityBondsAtomic(BigInt(a.availableUsdAtomic), BigInt(state.hairCutBps ?? 0));
  if (state.issuedBondsAtomic + mintAmountBondsAtomic > capacity) throw new Error("mint exceeds verified reserve capacity");
}

export function reserveRatioBps(state) {
  if (state.issuedBondsAtomic <= 0n) return 10_000n;
  const reserve = BigInt(state.attestation?.availableUsdAtomic ?? 0n) * BONDS_UNIT;
  return reserve * 10_000n / (state.issuedBondsAtomic * USD_UNIT);
}

export function reconcileReserve(state, now = Date.now()) {
  const a = state.attestation;
  if (!a || !a.verified) return { status: "blocked", reason: "verified reserve attestation required" };
  try { validateAttestation(a, now); } catch (e) { return { status: "blocked", reason: e.message }; }
  const capacity = reserveCapacityBondsAtomic(BigInt(a.availableUsdAtomic), BigInt(state.hairCutBps ?? 0));
  return {
    status: state.issuedBondsAtomic <= capacity ? "reconciled" : "deficit",
    issuedBondsAtomic: state.issuedBondsAtomic.toString(),
    eligibleBondsAtomic: capacity.toString(),
    reserveRatioBps: reserveRatioBps(state).toString(),
    attestationDigest: attestationDigest(a)
  };
}
