import fs from 'node:fs';
import path from 'node:path';
import { sha256, blockHash } from '../../node/protocol.mjs';

export function stateDigest(state) { return sha256(JSON.stringify(state, Object.keys(state).sort())); }

export function writeSnapshot(dir, chain) {
  const snapshot = { version: 1, height: chain.height, tip: chain.tip.hash,
    accounts: Object.fromEntries([...chain.accounts.entries()].sort(([a],[b])=>a.localeCompare(b))),
    totalSupply: chain.totalSupply.toString() };
  snapshot.digest = sha256(JSON.stringify(snapshot));
  const file = path.join(dir, `snapshot-${chain.height}.json`);
  fs.writeFileSync(file, JSON.stringify(snapshot, null, 2)+'\n', 'utf8');
  return file;
}

export function loadSnapshot(file) {
  const s = JSON.parse(fs.readFileSync(file,'utf8'));
  const digest = s.digest; delete s.digest;
  if (sha256(JSON.stringify(s)) !== digest) throw new Error('snapshot integrity failure');
  s.digest = digest; return s;
}

export function verifyChainBlocks(blocks, cfg) {
  if (!blocks.length) throw new Error('empty chain');
  for (let i=0;i<blocks.length;i++) {
    const b=blocks[i];
    if (b.chainId!==cfg.chainId) throw new Error(`chain id mismatch at ${i}`);
    if (b.height!==i) throw new Error(`height mismatch at ${i}`);
    if (b.hash!==blockHash(b)) throw new Error(`block hash mismatch at ${i}`);
    if (i===0) { if (b.previousHash!=='0'.repeat(64)) throw new Error('bad genesis predecessor'); }
    else if (b.previousHash!==blocks[i-1].hash) throw new Error(`predecessor mismatch at ${i}`);
    if (b.difficulty>0 && !b.hash.startsWith('0'.repeat(b.difficulty))) throw new Error(`pow failure at ${i}`);
    if (!Array.isArray(b.transactions)) throw new Error(`transactions malformed at ${i}`);
  }
  return true;
}

export function cumulativeWork(blocks) { return blocks.reduce((n,b)=>n + (1n << BigInt(Math.max(0, b.difficulty))), 0n); }
