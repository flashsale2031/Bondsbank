export interface Order {
  id: string;
  owner: string;
  side: "buy" | "sell";
  price: bigint;
  quantity: bigint;
  createdAt: number;
}

export class OrderBook {
  readonly buys: Order[] = [];
  readonly sells: Order[] = [];

  add(order: Order) {
    (order.side === "buy" ? this.buys : this.sells).push(order);
    this.sort();
  }

  private sort() {
    this.buys.sort((a,b)=>Number(b.price-a.price) || a.createdAt-b.createdAt);
    this.sells.sort((a,b)=>Number(a.price-b.price) || a.createdAt-b.createdAt);
  }

  bestBid() { return this.buys[0]; }
  bestAsk() { return this.sells[0]; }
}
