export interface StrategySignal {
  action: "buy" | "sell" | "hold";
  reason: string;
  confidence: number;
}

export interface RiskLimits {
  maxOrderValue: bigint;
  maxDailyLoss: bigint;
}

/** Strategy-only boundary. Exchange credentials and execution belong outside source control. */
export function safeSignal(action: StrategySignal, risk: RiskLimits): StrategySignal {
  if (action.confidence < 0 || action.confidence > 1) throw new Error("confidence must be 0..1");
  if (risk.maxOrderValue <= 0n) throw new Error("maxOrderValue must be positive");
  return action;
}
