export interface PrivacyAdapter {
  mode: "transparent" | "shielded";
  validateProof(proof: Uint8Array, statement: Uint8Array): Promise<boolean>;
}

/** Production placeholder: wire to an independently audited ZK implementation. */
export class DisabledPrivacyAdapter implements PrivacyAdapter {
  mode = "transparent" as const;
  async validateProof(): Promise<boolean> { return false; }
}
