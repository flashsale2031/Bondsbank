import {
  createHash, generateKeyPairSync, sign, verify, KeyObject
} from "node:crypto";

export const sha256 = (value: string): string =>
  createHash("sha256").update(value).digest("hex");

export interface KeyPair {
  privateKey: string;
  publicKey: string;
}

export function createKeyPair(): KeyPair {
  const { privateKey, publicKey } = generateKeyPairSync("ed25519");
  return {
    privateKey: privateKey.export({ type: "pkcs8", format: "pem" }).toString(),
    publicKey: publicKey.export({ type: "spki", format: "pem" }).toString()
  };
}

export function addressFromPublicKey(publicKey: string): string {
  return "B" + sha256(publicKey).slice(0, 40);
}

export function signMessage(privateKeyPem: string, message: string): string {
  const key = KeyObject.createPrivateKey(privateKeyPem);
  return sign(null, Buffer.from(message), key).toString("base64");
}

export function verifyMessage(publicKeyPem: string, message: string, signature: string): boolean {
  const key = KeyObject.createPublicKey(publicKeyPem);
  return verify(null, Buffer.from(message), key, Buffer.from(signature, "base64"));
}
