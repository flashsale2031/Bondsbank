import { createKeyPair, addressFromPublicKey, signMessage } from "./crypto.js";
import { Transaction } from "../../shared/src/types.js";
import { txPayload } from "./ledger.js";
import { randomUUID } from "node:crypto";

export function createWallet() {
  const keys = createKeyPair();
  return {...keys, address: addressFromPublicKey(keys.publicKey)};
}

export function createTransaction(
  wallet: { privateKey: string; publicKey: string; address: string },
  to: string, amount: bigint, fee: bigint, nonce: number
): Transaction {
  const unsigned = {
    from: wallet.address, to, amount, fee, nonce,
    timestamp: Date.now(), publicKey: wallet.publicKey
  };
  const signature = signMessage(wallet.privateKey, txPayload({...unsigned, id: "", signature: ""}));
  const tx = {...unsigned, id: "", signature};
  tx.id = randomUUID();
  return tx;
}
