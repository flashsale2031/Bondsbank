import { createServer } from "node:http";
import { Ledger } from "../../core/src/ledger.js";
import { createWallet, createTransaction } from "../../core/src/wallet.js";

const genesis = createWallet();
const ledger = new Ledger(genesis.address);

function json(res: any, status: number, value: unknown) {
  res.writeHead(status, {"content-type":"application/json"});
  res.end(JSON.stringify(value, (_, v) => typeof v === "bigint" ? v.toString() : v));
}

const server = createServer(async (req, res) => {
  try {
    const url = new URL(req.url ?? "/", "http://localhost");
    if (req.method === "GET" && url.pathname === "/") {
      return json(res, 200, {
        name: "Bonds Coin", symbol: "BONDS", network: "bonds-testnet",
        height: ledger.height, supply: ledger.supply
      });
    }
    if (req.method === "GET" && url.pathname.startsWith("/account/")) {
      return json(res, 200, ledger.getAccount(url.pathname.split("/")[2]));
    }
    if (req.method === "GET" && url.pathname === "/blocks") {
      return json(res, 200, ledger.blocks);
    }
    return json(res, 404, {error:"not found"});
  } catch (e) {
    return json(res, 500, {error: e instanceof Error ? e.message : String(e)});
  }
});

server.listen(Number(process.env.PORT ?? 8080), () =>
  console.log("BONDS test node listening on http://localhost:" + (process.env.PORT ?? 8080))
);
