export type Network = "bonds-mainnet" | "bonds-testnet";

export interface Transaction {
  id: string;
  from: string;
  to: string;
  amount: bigint;
  fee: bigint;
  nonce: number;
  timestamp: number;
  publicKey: string;
  signature: string;
}

export interface Block {
  height: number;
  previousHash: string;
  timestamp: number;
  nonce: number;
  difficulty: number;
  miner: string;
  transactions: Transaction[];
  hash: string;
}

export interface Account {
  address: string;
  balance: bigint;
  nonce: number;
}
