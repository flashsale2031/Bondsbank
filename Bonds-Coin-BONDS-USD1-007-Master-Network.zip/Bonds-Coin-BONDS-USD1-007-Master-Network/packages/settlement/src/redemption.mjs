import { randomUUID, createHash } from "node:crypto";

export const RedemptionStatus = Object.freeze({ PENDING: "pending", APPROVED: "approved", SETTLED: "settled", CANCELLED: "cancelled" });

export class RedemptionBook {
  constructor({ issuerAddress }) {
    this.issuerAddress = issuerAddress;
    this.requests = new Map();
  }

  create({ holder, amountBondsAtomic, destination }) {
    if (!holder || !destination) throw new Error("holder and USD destination required");
    const amount = BigInt(amountBondsAtomic);
    if (amount <= 0n) throw new Error("redemption amount must be positive");
    const id = randomUUID();
    const request = { id, holder, amountBondsAtomic: amount, destination, status: RedemptionStatus.PENDING, createdAt: Date.now() };
    this.requests.set(id, request);
    return {...request};
  }

  approve(id) {
    const r = this.get(id);
    if (r.status !== RedemptionStatus.PENDING) throw new Error("redemption is not pending");
    r.status = RedemptionStatus.APPROVED; r.approvedAt = Date.now();
    return {...r};
  }

  settle(id, settlementReference) {
    const r = this.get(id);
    if (r.status !== RedemptionStatus.APPROVED) throw new Error("redemption must be approved before settlement");
    if (!settlementReference) throw new Error("settlement reference required");
    r.status = RedemptionStatus.SETTLED; r.settlementReference = settlementReference; r.settledAt = Date.now();
    return {...r};
  }

  cancel(id) {
    const r = this.get(id);
    if (r.status === RedemptionStatus.SETTLED) throw new Error("settled redemption cannot be cancelled");
    r.status = RedemptionStatus.CANCELLED; r.cancelledAt = Date.now();
    return {...r};
  }

  get(id) { const r = this.requests.get(id); if (!r) throw new Error("redemption not found"); return r; }
  digest(id) { return createHash("sha256").update(JSON.stringify(this.get(id), (_,v)=>typeof v === "bigint" ? v.toString() : v)).digest("hex"); }
}
