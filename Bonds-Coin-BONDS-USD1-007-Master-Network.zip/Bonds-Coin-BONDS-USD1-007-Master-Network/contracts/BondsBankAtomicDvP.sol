// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

interface IBBUSD {
    function transferFrom(address from, address to, uint256 amount) external returns (bool);
}

/// @title Bonds Bank Atomic Delivery-versus-Payment Escrow
/// @notice Minimal bilateral DvP primitive: both legs execute or neither does.
contract BondsBankAtomicDvP {
    struct Trade {
        address buyer;
        address seller;
        address cashToken;
        address assetToken;
        uint256 cashAmount;
        uint256 assetAmount;
        bool executed;
        bool cancelled;
    }

    mapping(bytes32 => Trade) public trades;
    event TradeCreated(bytes32 indexed tradeId, address buyer, address seller, uint256 cashAmount, uint256 assetAmount);
    event TradeExecuted(bytes32 indexed tradeId);
    event TradeCancelled(bytes32 indexed tradeId);

    function createTrade(bytes32 tradeId, address buyer, address seller, address cashToken, address assetToken, uint256 cashAmount, uint256 assetAmount) external {
        require(tradeId != bytes32(0) && trades[tradeId].buyer == address(0), "trade exists");
        require(buyer != address(0) && seller != address(0) && cashToken != address(0) && assetToken != address(0), "zero");
        require(cashAmount > 0 && assetAmount > 0, "amount");
        trades[tradeId] = Trade(buyer, seller, cashToken, assetToken, cashAmount, assetAmount, false, false);
        emit TradeCreated(tradeId, buyer, seller, cashAmount, assetAmount);
    }

    /// @dev Buyer and seller approve this contract for their respective token legs before calling.
    function execute(bytes32 tradeId) external {
        Trade storage t = trades[tradeId];
        require(t.buyer != address(0) && !t.executed && !t.cancelled, "trade");
        require(IBBUSD(t.cashToken).transferFrom(t.buyer, t.seller, t.cashAmount), "cash leg");
        require(IBBUSD(t.assetToken).transferFrom(t.seller, t.buyer, t.assetAmount), "asset leg");
        t.executed = true;
        emit TradeExecuted(tradeId);
    }

    function cancel(bytes32 tradeId) external {
        Trade storage t = trades[tradeId];
        require(msg.sender == t.buyer || msg.sender == t.seller, "party");
        require(!t.executed && !t.cancelled, "trade state");
        t.cancelled = true;
        emit TradeCancelled(tradeId);
    }
}
