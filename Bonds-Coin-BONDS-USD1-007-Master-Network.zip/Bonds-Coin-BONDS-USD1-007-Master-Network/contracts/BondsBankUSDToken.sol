// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @title Bonds Bank Tokenized USD Credit
/// @notice Permissioned ERC-20-style token for a 1:1 reserve/redemption loop.
/// @dev Production deployment requires independent audit, approved legal issuer,
///      custody/reserve evidence, and controlled issuer keys. This source is not audited.
contract BondsBankUSDToken {
    string public constant name = "Bonds Bank Tokenized USD Credit";
    string public constant symbol = "BBUSD";
    uint8 public constant decimals = 6;

    bytes32 public constant ISSUER_ROLE = keccak256("ISSUER_ROLE");
    bytes32 public constant COMPLIANCE_ROLE = keccak256("COMPLIANCE_ROLE");
    bytes32 public constant PAUSER_ROLE = keccak256("PAUSER_ROLE");

    uint256 public totalSupply;
    uint256 public verifiedReserveUsdMicros;
    uint256 public pendingRedemptionsUsdMicros;
    bool public paused;

    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;
    mapping(address => bool) public kycApproved;
    mapping(address => bool) public frozen;
    mapping(bytes32 => bool) public processedDepositIds;
    mapping(bytes32 => bool) public processedRedemptionIds;
    mapping(bytes32 => bool) public processedSettlementIds;
    mapping(bytes32 => bool) private _roles;

    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);
    event KycStatusChanged(address indexed account, bool approved);
    event FreezeStatusChanged(address indexed account, bool frozen);
    event ReserveEvidenceUpdated(uint256 verifiedReserveUsdMicros, bytes32 evidenceHash);
    event Minted(bytes32 indexed depositId, address indexed account, uint256 amount);
    event RedemptionRequested(bytes32 indexed redemptionId, address indexed account, uint256 amount);
    event RedemptionSettled(bytes32 indexed redemptionId, bytes32 indexed settlementId, address indexed account, uint256 amount);
    event Burned(bytes32 indexed redemptionId, address indexed account, uint256 amount);
    event Paused(bool value);

    constructor(address admin, address issuer, address compliance, address pauser) {
        require(admin != address(0) && issuer != address(0) && compliance != address(0) && pauser != address(0), "zero role");
        _roles[keccak256(abi.encodePacked(bytes32(0), admin))] = true;
        _roles[keccak256(abi.encodePacked(ISSUER_ROLE, issuer))] = true;
        _roles[keccak256(abi.encodePacked(COMPLIANCE_ROLE, compliance))] = true;
        _roles[keccak256(abi.encodePacked(PAUSER_ROLE, pauser))] = true;
    }

    modifier onlyRole(bytes32 role) {
        require(_roles[keccak256(abi.encodePacked(role, msg.sender))], "role");
        _;
    }

    modifier whenNotPaused() {
        require(!paused, "paused");
        _;
    }

    function hasRole(bytes32 role, address account) external view returns (bool) {
        return _roles[keccak256(abi.encodePacked(role, account))];
    }

    function setKycApproved(address account, bool approved) external onlyRole(COMPLIANCE_ROLE) {
        require(account != address(0), "zero account");
        kycApproved[account] = approved;
        emit KycStatusChanged(account, approved);
    }

    function setFrozen(address account, bool value) external onlyRole(COMPLIANCE_ROLE) {
        frozen[account] = value;
        emit FreezeStatusChanged(account, value);
    }

    function setPaused(bool value) external onlyRole(PAUSER_ROLE) {
        paused = value;
        emit Paused(value);
    }

    /// @notice Update independently verified reserve capacity. Value is denominated in USD micros.
    function setVerifiedReserve(uint256 reserveUsdMicros, bytes32 evidenceHash) external onlyRole(ISSUER_ROLE) {
        require(evidenceHash != bytes32(0), "evidence");
        require(reserveUsdMicros >= totalSupply + pendingRedemptionsUsdMicros, "under-reserved");
        verifiedReserveUsdMicros = reserveUsdMicros;
        emit ReserveEvidenceUpdated(reserveUsdMicros, evidenceHash);
    }

    /// @notice Mint exactly the verified bank-deposit amount, once per external deposit id.
    function mintFromVerifiedDeposit(bytes32 depositId, address account, uint256 amount) external onlyRole(ISSUER_ROLE) whenNotPaused {
        require(depositId != bytes32(0) && !processedDepositIds[depositId], "deposit replay");
        require(account != address(0) && kycApproved[account] && !frozen[account], "recipient compliance");
        require(amount > 0, "amount");
        require(totalSupply + amount <= verifiedReserveUsdMicros, "reserve capacity");
        processedDepositIds[depositId] = true;
        totalSupply += amount;
        balanceOf[account] += amount;
        emit Transfer(address(0), account, amount);
        emit Minted(depositId, account, amount);
    }

    function transfer(address to, uint256 amount) external whenNotPaused returns (bool) {
        _move(msg.sender, to, amount);
        return true;
    }

    function approve(address spender, uint256 amount) external whenNotPaused returns (bool) {
        allowance[msg.sender][spender] = amount;
        emit Approval(msg.sender, spender, amount);
        return true;
    }

    function transferFrom(address from, address to, uint256 amount) external whenNotPaused returns (bool) {
        uint256 allowed = allowance[from][msg.sender];
        require(allowed >= amount, "allowance");
        allowance[from][msg.sender] = allowed - amount;
        emit Approval(from, msg.sender, allowance[from][msg.sender]);
        _move(from, to, amount);
        return true;
    }

    function requestRedemption(bytes32 redemptionId, uint256 amount) external whenNotPaused {
        require(redemptionId != bytes32(0) && !processedRedemptionIds[redemptionId], "redemption replay");
        require(kycApproved[msg.sender] && !frozen[msg.sender], "holder compliance");
        require(amount > 0 && balanceOf[msg.sender] >= amount, "balance");
        processedRedemptionIds[redemptionId] = true;
        pendingRedemptionsUsdMicros += amount;
        emit RedemptionRequested(redemptionId, msg.sender, amount);
    }

    /// @notice Settlement must be confirmed by the issuer's controlled banking/settlement adapter before burn.
    function settleAndBurn(bytes32 redemptionId, bytes32 settlementId, address account, uint256 amount)
        external onlyRole(ISSUER_ROLE) whenNotPaused {
        require(settlementId != bytes32(0) && !processedSettlementIds[settlementId], "settlement replay");
        require(processedRedemptionIds[redemptionId], "redemption");
        require(amount > 0 && pendingRedemptionsUsdMicros >= amount, "pending");
        require(balanceOf[account] >= amount && kycApproved[account] && !frozen[account], "account");
        processedSettlementIds[settlementId] = true;
        pendingRedemptionsUsdMicros -= amount;
        balanceOf[account] -= amount;
        totalSupply -= amount;
        emit Transfer(account, address(0), amount);
        emit RedemptionSettled(redemptionId, settlementId, account, amount);
        emit Burned(redemptionId, account, amount);
    }

    function availableReserveCapacity() external view returns (uint256) {
        uint256 committed = totalSupply + pendingRedemptionsUsdMicros;
        return verifiedReserveUsdMicros > committed ? verifiedReserveUsdMicros - committed : 0;
    }

    function _move(address from, address to, uint256 amount) internal {
        require(from != address(0) && to != address(0), "zero address");
        require(kycApproved[from] && kycApproved[to], "recipient compliance");
        require(!frozen[from] && !frozen[to], "frozen");
        require(balanceOf[from] >= amount, "balance");
        balanceOf[from] -= amount;
        balanceOf[to] += amount;
        emit Transfer(from, to, amount);
    }
}
