# Independent Smart-Contract & Security Audit Engagement Package

**Status: pre-audit package. This is not an independent audit opinion.**

Scope:
- `contracts/BondsBankUSDToken.sol`
- `contracts/BondsBankAtomicDvP.sol`
- mint/burn/redeem invariants
- reserve-capacity invariants
- role and key-management boundaries
- KYC/freeze transfer controls
- replay protection
- emergency pause
- external bank/custody/KYC/KMS adapters
- RPC/P2P attack surface and deployment configuration

Required independent procedures:
- manual source review
- static analysis
- fuzz/property testing
- privilege/escalation review
- economic/invariant analysis
- dependency and supply-chain review
- deployment verification
- remediation retest
- signed final report by an independent security firm

Launch condition: mainnet activation remains blocked until an independent report exists, findings are remediated or accepted by documented governance, and the auditor signs the final scope/results.
