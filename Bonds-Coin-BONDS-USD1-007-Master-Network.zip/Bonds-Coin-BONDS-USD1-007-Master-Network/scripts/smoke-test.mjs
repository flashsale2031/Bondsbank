import { spawn } from "node:child_process";
const child = spawn(process.execPath, ["packages/node/dist/server.js"], {stdio:["ignore","pipe","pipe"]});
await new Promise(r=>setTimeout(r,500));
const response = await fetch("http://localhost:8080/");
const data = await response.json();
console.log(JSON.stringify(data,null,2));
child.kill();
if (data.symbol !== "BONDS" || data.name !== "Bonds Coin") process.exit(1);
console.log("BONDS smoke test passed.");
