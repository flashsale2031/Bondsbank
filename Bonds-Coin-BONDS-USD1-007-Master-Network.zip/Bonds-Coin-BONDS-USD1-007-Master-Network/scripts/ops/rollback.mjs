import fs from 'node:fs';
import path from 'node:path';
import cfg from '../../config/mainnet.json' with {type:'json'};
const data=process.env.BONDS_DATA_DIR||cfg.dataDir;
const backupRoot=process.env.BONDS_BACKUP_DIR||path.join(data,'backups');
const name=process.argv[2]; if(!name) throw new Error('usage: node scripts/ops/rollback.mjs <backup-directory-name>');
const src=path.join(backupRoot,name); if(!fs.existsSync(src)) throw new Error('backup not found');
for(const f of ['chain.jsonl','state.json','MANIFEST.json']) if(!fs.existsSync(path.join(src,f))) throw new Error(`backup incomplete: ${f}`);
const manifest=JSON.parse(fs.readFileSync(path.join(src,'MANIFEST.json')));
for(const f of ['chain.jsonl','state.json']) {const h=await import('node:crypto').then(c=>c.createHash('sha256').update(fs.readFileSync(path.join(src,f))).digest('hex')); if(h!==manifest.files[f].sha256) throw new Error(`checksum mismatch: ${f}`)}
fs.copyFileSync(path.join(src,'chain.jsonl'),path.join(data,'chain.jsonl'));
fs.copyFileSync(path.join(src,'state.json'),path.join(data,'state.json'));
console.log(JSON.stringify({ok:true,restored:name,requiresRestart:true}));
