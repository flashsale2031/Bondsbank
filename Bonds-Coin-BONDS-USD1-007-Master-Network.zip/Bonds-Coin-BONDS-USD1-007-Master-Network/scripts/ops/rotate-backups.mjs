import fs from 'node:fs';
import path from 'node:path';
import cfg from '../../config/mainnet.json' with {type:'json'};
const dir=process.env.BONDS_BACKUP_DIR||path.join(process.env.BONDS_DATA_DIR||cfg.dataDir,'backups');
const keep=Math.max(1,Number(process.env.BONDS_BACKUP_KEEP||14));
if(!fs.existsSync(dir)){console.log(JSON.stringify({backups:0,removed:0}));process.exit(0)}
const entries=fs.readdirSync(dir,{withFileTypes:true}).filter(e=>e.isDirectory()).sort((a,b)=>b.name.localeCompare(a.name));
let removed=0;for(const e of entries.slice(keep)){fs.rmSync(path.join(dir,e.name),{recursive:true,force:true});removed++}
console.log(JSON.stringify({backups:Math.min(entries.length,keep),removed,keep}));
