import fs from 'node:fs';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
const root=process.cwd();
const version=process.env.BONDS_VERSION||'production';
const backup=process.env.BONDS_BACKUP_DIR||path.join(process.env.BONDS_DATA_DIR||'./data/mainnet','backups');
function run(cmd,args){console.log('$',cmd,...args);execFileSync(cmd,args,{stdio:'inherit',cwd:root})}
run('node',['scripts/backup-data.mjs']);
run('node',['scripts/production-readiness.mjs']);
console.log(JSON.stringify({ok:true,version,backup,action:'ready-for-deployment'}));
