import fs from 'node:fs'; import path from 'node:path'; import crypto from 'node:crypto';
const root=process.cwd(); const skip=new Set(['.git','node_modules','data','release']); const files=[];
function walk(d){for(const n of fs.readdirSync(d).sort()){if(skip.has(n))continue;const p=path.join(d,n),st=fs.statSync(p);if(st.isDirectory())walk(p);else files.push(p)}}
walk(root); const manifest=files.map(p=>{const h=crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');return `${h}  ${path.relative(root,p).replaceAll('\\','/')}`}).join('\n')+'\n';
fs.mkdirSync('release',{recursive:true});fs.writeFileSync('release/SHA256SUMS',manifest);const rootHash=crypto.createHash('sha256').update(manifest).digest('hex');fs.writeFileSync('release/RELEASE-METADATA.json',JSON.stringify({format:1,rootHash,fileCount:files.length,node:process.version},null,2)+'\n');console.log(JSON.stringify({rootHash,fileCount:files.length}));
