const base=process.env.BONDS_RPC_URL||'http://127.0.0.1:8080';
const token=process.env.BONDS_RPC_TOKEN||'';
const h=await fetch(base+'/health/live'); if(!h.ok) throw new Error(`liveness ${h.status}`);
const r=await fetch(base+'/health/ready'); console.log('readiness',r.status,await r.text());
const headers=token?{authorization:`Bearer ${token}`}:{};
const m=await fetch(base+'/metrics',{headers}); if(!m.ok) throw new Error(`metrics ${m.status}`);
console.log(await m.text());
