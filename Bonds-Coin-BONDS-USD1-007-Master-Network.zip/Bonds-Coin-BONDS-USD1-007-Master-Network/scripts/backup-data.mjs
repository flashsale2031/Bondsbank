import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import cfg from '../config/mainnet.json' with {type:'json'};

const dataDir=process.env.BONDS_DATA_DIR||cfg.dataDir;
const outDir=process.env.BONDS_BACKUP_DIR||path.join(dataDir,'backups');
fs.mkdirSync(outDir,{recursive:true,mode:0o700});
const required=['chain.jsonl','state.json'];
for(const f of required){ if(!fs.existsSync(path.join(dataDir,f))) throw new Error(`missing ${f}`); }
const stamp=new Date().toISOString().replace(/[:.]/g,'-');
const dir=path.join(outDir,stamp); fs.mkdirSync(dir,{recursive:true,mode:0o700});
for(const f of required) fs.copyFileSync(path.join(dataDir,f),path.join(dir,f),fs.constants.COPYFILE_EXCL);
const manifest={createdAt:new Date().toISOString(),files:{}};
for(const f of required){const p=path.join(dir,f); manifest.files[f]={bytes:fs.statSync(p).size,sha256:crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex')};}
fs.writeFileSync(path.join(dir,'MANIFEST.json'),JSON.stringify(manifest,null,2),{mode:0o600});
console.log(JSON.stringify({backup:dir,manifest},null,2));
