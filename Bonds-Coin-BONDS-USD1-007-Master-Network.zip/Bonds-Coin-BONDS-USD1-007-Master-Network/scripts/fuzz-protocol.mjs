import {txVerify, blockHash} from '../node/protocol.mjs';
let crashes=0; const rnd=()=>Math.random().toString(36).repeat(8).slice(0,256);
for(let i=0;i<10000;i++){const x=Math.random()<.5?null:{chainId:rnd(),network:rnd(),from:rnd(),to:rnd(),amount:rnd(),fee:rnd(),nonce:i,timestamp:Date.now(),publicKey:rnd(),signature:rnd()};try{txVerify(x)}catch{crashes++}try{blockHash({version:rnd(),chainId:rnd(),height:rnd(),previousHash:rnd(),timestamp:rnd(),nonce:rnd(),difficulty:rnd(),miner:rnd(),transactions:[x]})}catch{crashes++}}
if(crashes) {console.error(`fuzz crashes: ${crashes}`);process.exit(1)} console.log('protocol fuzz: 20000 malformed-input iterations, 0 uncaught crashes');
