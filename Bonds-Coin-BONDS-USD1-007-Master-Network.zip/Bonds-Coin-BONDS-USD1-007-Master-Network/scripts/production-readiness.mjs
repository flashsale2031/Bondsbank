import fs from 'node:fs';
import cfg from '../config/mainnet.json' with {type:'json'};
import {evaluateProductionReadiness} from '../packages/production/src/readiness-gate.mjs';
const result=evaluateProductionReadiness({config:cfg,reserveValid:false,custodyConfigured:false,keysAudited:false,externalAuditPassed:false,testnetPassed:false});
console.log(JSON.stringify(result,null,2));
process.exitCode=result.ready?0:2;
