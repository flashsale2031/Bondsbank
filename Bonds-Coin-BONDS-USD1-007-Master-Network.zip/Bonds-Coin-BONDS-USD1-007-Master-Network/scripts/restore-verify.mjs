import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const dir=process.argv[2];
if(!dir) throw new Error('usage: node scripts/restore-verify.mjs <backup-dir>');
const manifest=JSON.parse(fs.readFileSync(path.join(dir,'MANIFEST.json'),'utf8'));
for(const [name,meta] of Object.entries(manifest.files)){
 const p=path.join(dir,name); if(!fs.existsSync(p)) throw new Error(`missing ${name}`);
 const bytes=fs.statSync(p).size; const hash=crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
 if(bytes!==meta.bytes||hash!==meta.sha256) throw new Error(`integrity failure: ${name}`);
}
console.log(JSON.stringify({ok:true,createdAt:manifest.createdAt,files:Object.keys(manifest.files)},null,2));
