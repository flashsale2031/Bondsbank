import fs from 'node:fs'; import crypto from 'node:crypto';
const sums=fs.readFileSync('release/SHA256SUMS','utf8').trim().split('\n').filter(Boolean);
let bad=[]; for(const line of sums){const [want,...parts]=line.trim().split(/\s+/);const file=parts.join(' ');if(!fs.existsSync(file)){bad.push(`${file}:missing`);continue}const got=crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');if(got!==want)bad.push(`${file}:checksum`)}
const meta=JSON.parse(fs.readFileSync('release/RELEASE-METADATA.json'));const root=crypto.createHash('sha256').update(fs.readFileSync('release/SHA256SUMS')).digest('hex');if(root!==meta.rootHash)bad.push('rootHash');
if(bad.length){console.error(JSON.stringify({ok:false,bad},null,2));process.exit(1)}console.log(JSON.stringify({ok:true,fileCount:sums.length,rootHash:root},null,2));
