import crypto from 'node:crypto';

export const NETWORK_007 = Object.freeze({
  id: '007',
  name: '007 Master Network',
  role: 'interoperability-and-settlement-hub',
  nativeAsset: 'BONDS',
  designGoal: 'unified interoperability without pretending every chain shares one consensus or security model'
});

const hex = b => Buffer.from(b).toString('hex');
const hash = s => hex(crypto.createHash('sha256').update(s).digest());

export class NetworkRegistry {
  #chains = new Map();
  registerChain(chain) {
    if (!chain?.id || !chain?.name || !chain?.adapter) throw new Error('invalid chain adapter');
    if (this.#chains.has(chain.id)) throw new Error('chain already registered');
    this.#chains.set(chain.id, Object.freeze({...chain}));
    return chain.id;
  }
  get(id) { return this.#chains.get(id); }
  list() { return [...this.#chains.values()].map(({adapter, ...c}) => c); }
  adapters() { return [...this.#chains.values()]; }
}

export class UniversalAssetRegistry {
  #assets = new Map();
  register(asset) {
    if (!asset?.id || !asset?.chainId || !asset?.symbol) throw new Error('invalid asset');
    if (this.#assets.has(asset.id)) throw new Error('asset already registered');
    this.#assets.set(asset.id, Object.freeze({...asset}));
    return asset.id;
  }
  get(id) { return this.#assets.get(id); }
  list() { return [...this.#assets.values()]; }
}

export class ConverterRouter {
  constructor({chains, assets, routes=[]}={}) { this.chains=chains; this.assets=assets; this.routes=routes; }
  quote({fromAsset,toAsset,amount}) {
    if (!(BigInt(amount) > 0n)) throw new Error('amount must be positive');
    const a=this.assets.get(fromAsset), b=this.assets.get(toAsset);
    if (!a || !b) throw new Error('unknown asset');
    if (a.id===b.id) return {path:[a.id], amountIn:String(amount), amountOut:String(amount), feeBps:0};
    const direct=this.routes.find(r=>r.fromAsset===a.id&&r.toAsset===b.id);
    if (!direct) throw new Error('no executable liquidity route');
    const fee=BigInt(amount)*BigInt(direct.feeBps)/10000n;
    return {path:[a.id,b.id],amountIn:String(amount),amountOut:String(BigInt(amount)-fee),feeBps:direct.feeBps,routeId:direct.id};
  }
  plan({fromAsset,toAsset,amount,recipient}) {
    const q=this.quote({fromAsset,toAsset,amount});
    const id=hash(JSON.stringify({network:'007',q,recipient,nonce:crypto.randomUUID()}));
    return {id,network:'007',status:'planned',fromAsset,toAsset,recipient,...q,atomic:true};
  }
}

export class BridgeMessageBus {
  #seen = new Set();
  constructor({signer}) { this.signer=signer; }
  create(message) {
    const body={version:1,network:'007',messageId:crypto.randomUUID(),createdAt:new Date().toISOString(),...message};
    const canonical=JSON.stringify(body);
    const signature=this.signer(canonical);
    return {body,signature};
  }
  accept(packet) {
    if (!packet?.body?.messageId || !packet.signature) throw new Error('invalid bridge packet');
    if (this.#seen.has(packet.body.messageId)) throw new Error('bridge message replay');
    this.#seen.add(packet.body.messageId);
    return packet.body;
  }
}

export function create007({chains, assets, routes, signer=canonical=>hash(canonical)}) {
  const registry=new NetworkRegistry();
  for (const c of chains||[]) registry.registerChain(c);
  const assetRegistry=new UniversalAssetRegistry();
  for (const a of assets||[]) assetRegistry.register(a);
  return Object.freeze({
    network: NETWORK_007,
    chains: registry,
    assets: assetRegistry,
    converter: new ConverterRouter({chains:registry,assets:assetRegistry,routes}),
    bridge: new BridgeMessageBus({signer})
  });
}
