import fs from 'node:fs';
import {generateKeyPairSync, createPrivateKey, createPublicKey, sign, verify} from 'node:crypto';
import {address} from './protocol.mjs';
export function loadPeerIdentity(file) {
  if (fs.existsSync(file)) return JSON.parse(fs.readFileSync(file,'utf8'));
  const {privateKey,publicKey}=generateKeyPairSync('ed25519');
  const out={privateKey:privateKey.export({type:'pkcs8',format:'pem'}).toString(),publicKey:publicKey.export({type:'spki',format:'pem'}).toString()};
  out.id=address(out.publicKey); fs.writeFileSync(file,JSON.stringify(out,null,2),{mode:0o600}); return out;
}
export const peerSign=(identity,msg)=>sign(null,Buffer.from(msg),createPrivateKey(identity.privateKey)).toString('base64');
export const peerVerify=(publicKey,msg,sig)=>verify(null,Buffer.from(msg),createPublicKey(publicKey),Buffer.from(sig,'base64'));
