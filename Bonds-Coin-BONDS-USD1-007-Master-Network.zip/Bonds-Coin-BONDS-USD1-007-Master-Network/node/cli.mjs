import fs from "node:fs";
import {walletNew, txSign, UNIT} from "./protocol.mjs";

const [cmd,...args]=process.argv.slice(2);
if(cmd==="wallet"){
  const w=walletNew(); const file=args[0]||"wallet.json";
  fs.writeFileSync(file,JSON.stringify(w,null,2),{mode:0o600});
  console.log(`Created wallet ${file}\nAddress: ${w.address}`);
} else if(cmd==="genesis"){
  console.log("Mainnet genesis is generated deterministically from the node wallet on first startup.");
  console.log("Do NOT treat a local first-start genesis as the public genesis until a launch ceremony freezes and publishes it.");
} else {
  console.log("BONDS CLI\n  npm run wallet -- wallet.json\n  npm run genesis\n  npm start");
}
