import net from 'node:net';
import crypto from 'node:crypto';
import { peerSign, peerVerify } from './peer-identity.mjs';

export class P2P {
  constructor(node,cfg,identity){this.node=node;this.cfg=cfg;this.identity=identity;this.peers=new Set();this.inbound=0;this.challenge=crypto.randomBytes(16).toString('hex');}
  start(){this.server=net.createServer(s=>this.accept(s,true));this.server.maxConnections=this.cfg.maxInboundPeers||32;this.server.listen(this.cfg.p2pPort,this.cfg.p2pHost);}
  accept(socket,inbound=false){
    if(this.peers.size >= (this.cfg.maxPeers||64) || (inbound && this.inbound >= (this.cfg.maxInboundPeers||32))) return socket.destroy();
    if(inbound)this.inbound++;
    socket.setEncoding('utf8'); let buf=''; socket._authed=false;
    socket.on('data',d=>{buf+=d;let i;while((i=buf.indexOf('\n'))>=0){const line=buf.slice(0,i);buf=buf.slice(i+1);this.handle(socket,line)}});
    socket.on('close',()=>{this.peers.delete(socket);if(inbound)this.inbound=Math.max(0,this.inbound-1)}); socket.on('error',()=>socket.destroy()); this.peers.add(socket);
    this.send(socket,{type:'hello',network:this.cfg.network,protocolVersion:this.cfg.protocolVersion,height:this.node.chain.height,tip:this.node.chain.tip.hash,peerId:this.identity.id,publicKey:this.identity.publicKey,challenge:this.challenge,signature:peerSign(this.identity,`${this.cfg.network}|${this.cfg.protocolVersion}|${this.identity.id}|${this.challenge}`)});
  }
  connect(host,port){const s=net.createConnection(port,host,()=>this.accept(s,false));return s;}
  send(s,msg){try{s.write(JSON.stringify(msg)+'\n')}catch{}}
  broadcast(msg){for(const p of this.peers)if(p._authed)this.send(p,msg)}
  handle(s,line){let m;try{m=JSON.parse(line)}catch{return s.destroy()}
    if(m.type==='hello'){
      const signed=`${m.network}|${m.protocolVersion}|${m.peerId}|${m.challenge}`;
      if(m.network!==this.cfg.network||m.protocolVersion!==this.cfg.protocolVersion||!m.publicKey||!peerVerify(m.publicKey,signed,m.signature)) return s.destroy();
      if(this.cfg.peerAllowlist?.length && !this.cfg.peerAllowlist.includes(m.peerId)) return s.destroy();
      s._authed=true;
      if(m.height>this.node.chain.height)this.send(s,{type:'request_blocks',from:this.node.chain.height+1});
    } else if(this.cfg.peerAuthRequired && !s._authed) return s.destroy();
    else if(m.type==='tx'){try{this.node.chain.submitTx(m.tx);this.broadcast({type:'tx',tx:m.tx})}catch{}}
    else if(m.type==='request_blocks'){const from=Math.max(0,Number(m.from)||0);this.send(s,{type:'blocks',blocks:this.node.chain.blocks.slice(from)})}
    else if(m.type==='blocks'){if(!Array.isArray(m.blocks)||m.blocks.length>2000)return s.destroy();for(const b of m.blocks){try{this.node.chain.applyBlock(b)}catch{break}}}
  }
}
