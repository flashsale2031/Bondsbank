import { createHash, generateKeyPairSync, sign, verify, createPrivateKey, createPublicKey, randomUUID } from "node:crypto";

export const UNIT = 100000000n;
export const MAX_SUPPLY = 100000000000n * UNIT;
export const USD_PEG_ATOMIC_USD = 1000000n; // $1.00 USD represented in 6-decimal accounting
export const TX_TYPES = new Set(["transfer","mint","burn"]);

export const sha256 = s => createHash("sha256").update(s).digest("hex");
export const canonical = value => JSON.stringify(value, (_, v) => typeof v === "bigint" ? `${v}n` : v);

export function walletNew() {
  const {privateKey, publicKey} = generateKeyPairSync("ed25519");
  const priv = privateKey.export({type:"pkcs8",format:"pem"}).toString();
  const pub = publicKey.export({type:"spki",format:"pem"}).toString();
  return {privateKey:priv, publicKey:pub, address:address(pub)};
}
export function address(publicKey) { return "B"+sha256(publicKey).slice(0,40); }

export function txUnsigned(tx) {
  return canonical({chainId:tx.chainId,network:tx.network,type:tx.type||"transfer",from:tx.from,to:tx.to,
    amount:String(tx.amount),fee:String(tx.fee),nonce:tx.nonce,timestamp:tx.timestamp,
    publicKey:tx.publicKey});
}
export function txSign(wallet, tx) {
  const signature = sign(null, Buffer.from(txUnsigned(tx)), createPrivateKey(wallet.privateKey)).toString("base64");
  return {...tx, signature, id:sha256(txUnsigned({...tx,signature}))};
}
export function txVerify(tx) {
  try {
    return address(tx.publicKey)===tx.from &&
      verify(null, Buffer.from(txUnsigned(tx)), createPublicKey(tx.publicKey), Buffer.from(tx.signature,"base64"));
  } catch { return false; }
}
export function txId(tx) { return sha256(txUnsigned(tx)+":"+tx.signature); }

export function blockUnsigned(block) {
  return canonical({version:block.version,chainId:block.chainId,height:block.height,
    previousHash:block.previousHash,timestamp:block.timestamp,nonce:block.nonce,
    difficulty:block.difficulty,miner:block.miner,transactions:block.transactions});
}
export function blockHash(block) { return sha256(blockUnsigned(block)); }

export function makeGenesis(genesisAddress) {
  const b = {version:1,chainId:1001,height:0,previousHash:"0".repeat(64),timestamp:0,
    nonce:0,difficulty:0,miner:"genesis",transactions:[]};
  b.hash=blockHash(b);
  return {block:b,genesisAddress};
}
