import { sha256, blockHash, txVerify, txId, MAX_SUPPLY, TX_TYPES } from "./protocol.mjs";
import { verifyChainBlocks, cumulativeWork, writeSnapshot } from "../packages/protocol/recovery.mjs";

export class Chain {
  constructor(cfg, store, genesis) {
    this.cfg=cfg; this.store=store; this.blocks=store.loadBlocks();
    this.accounts=new Map();
    this.mempool=new Map();
    this.maxMempool = Number(cfg.maxMempool||5000);
    this.maxTxBytes = Number(cfg.maxTxBytes||100000);
    if(this.blocks.length===0) {
      this.blocks=[genesis.block];
      this.store.appendBlock(genesis.block);
      this.accounts.set(genesis.genesisAddress,{balance:"0",nonce:0});
      this.totalSupply = 0n;
      this.persist();
    } else {
      const saved=store.loadState();
      if(saved) {
        for(const [k,v] of Object.entries(saved.accounts||{})) this.accounts.set(k,v);
        this.totalSupply = BigInt(saved.totalSupply||"0");
      }
      else throw new Error("state.json missing; refuse unsafe replay without explicit recovery");
    }
  }
  get height(){return this.blocks.length-1}
  get tip(){return this.blocks.at(-1)}
  account(a){return this.accounts.get(a)||{balance:"0",nonce:0}}
  persist(){
    const accounts=Object.fromEntries(this.accounts);
    this.store.saveState({height:this.height,tip:this.tip.hash,accounts,totalSupply:this.totalSupply.toString()});
  }
  validateTx(tx) {
    if(JSON.stringify(tx).length>this.maxTxBytes) return "transaction too large";
    if(!Number.isSafeInteger(tx.nonce)||tx.nonce<0) return "invalid nonce";
    if(!Number.isSafeInteger(tx.timestamp)||Math.abs(Date.now()-tx.timestamp)>Number(cfg.maxTxAgeMs||300000)) return "transaction timestamp outside policy";
    if(tx.chainId!==this.cfg.chainId||tx.network!==this.cfg.network) return "wrong network";
    if(!txVerify(tx)) return "invalid signature";
    const type=tx.type||"transfer";
    if(!TX_TYPES.has(type)) return "invalid transaction type";
    const amount=BigInt(tx.amount), fee=BigInt(tx.fee);
    if(amount<=0n||fee<0n) return "invalid amount/fee";
    const a=this.account(tx.from);
    if(tx.nonce!==a.nonce) return `invalid nonce: expected ${a.nonce}`;
    const issuer=this.cfg.issuerAddress;
    if(type==="mint") {
      if(tx.from!==issuer) return "mint requires issuer";
      if(this.totalSupply+amount>MAX_SUPPLY) return "max supply exceeded";
      // Minting does not debit issuer funds; the issuer's off-chain reserve is the backing.
    } else {
      if(BigInt(a.balance)<amount+fee) return "insufficient balance";
      if(type==="burn" && tx.to!==issuer) return "burn must be sent to issuer";
    }
    if(this.mempool.has(tx.id)) return "duplicate transaction";
    if(this.mempool.size>=this.maxMempool) {
      const minFee=[...this.mempool.values()].reduce((m,t)=>BigInt(t.fee)<m?BigInt(t.fee):m,BigInt(tx.fee));
      if(BigInt(tx.fee)<=minFee) return "mempool full; fee too low";
    }
    return null;
  }
  submitTx(tx){
    tx.id ||= txId(tx);
    const e=this.validateTx(tx); if(e) throw new Error(e);
    this.mempool.set(tx.id,tx); return tx;
  }
  applyBlock(block) {
    if(block.height!==this.height+1) throw new Error("bad height");
    if(block.previousHash!==this.tip.hash) throw new Error("bad previous hash");
    if(block.hash!==blockHash(block)) throw new Error("bad block hash");
    if(block.difficulty>0 && !block.hash.startsWith("0".repeat(block.difficulty))) throw new Error("insufficient proof of work");
    if(JSON.stringify(block).length>this.cfg.maxBlockBytes) throw new Error("block too large");

    let fees=0n;
    for(const tx of block.transactions) {
      const e=this.validateTx(tx); if(e) throw new Error(e);
      const amount=BigInt(tx.amount), fee=BigInt(tx.fee);
      const type=tx.type||"transfer";
      const from=this.account(tx.from);
      from.nonce++;
      if(type==="mint") {
        const to=this.account(tx.to);
        to.balance=(BigInt(to.balance)+amount).toString();
        this.accounts.set(tx.to,to);
        this.totalSupply += amount;
      } else {
        from.balance=(BigInt(from.balance)-amount-fee).toString();
        this.accounts.set(tx.from,from);
        const to=this.account(tx.to); to.balance=(BigInt(to.balance)+amount).toString(); this.accounts.set(tx.to,to);
        if(type==="burn") this.totalSupply -= amount;
      }
      fees+=fee; this.mempool.delete(tx.id);
    }
    const miner=this.account(block.miner);
    miner.balance=(BigInt(miner.balance)+fees).toString(); this.accounts.set(block.miner,miner);
    this.blocks.push(block); this.store.appendBlock(block); this.persist();
    if(this.cfg.snapshotInterval && this.height % this.cfg.snapshotInterval===0) writeSnapshot(this.store.dir,this);
  }
  validateFullChain() { return verifyChainBlocks(this.blocks,this.cfg); }
  chainWork(blocks=this.blocks) { return cumulativeWork(blocks); }
  adoptChain(candidate) {
    verifyChainBlocks(candidate,this.cfg);
    if(candidate.length<=this.blocks.length) throw new Error("candidate chain is not longer");
    if(cumulativeWork(candidate)<=this.chainWork()) throw new Error("candidate chain has insufficient cumulative work");
    const tmp=Object.create(Chain.prototype);
    tmp.cfg=this.cfg; tmp.store={appendBlock(){},saveState(){},dir:this.store.dir}; tmp.blocks=[candidate[0]];
    tmp.accounts=new Map(); tmp.mempool=new Map(); tmp.maxMempool=this.maxMempool; tmp.maxTxBytes=this.maxTxBytes;
    tmp.accounts.set(this.cfg.issuerAddress,{balance:"0",nonce:0}); tmp.totalSupply=0n;
    for(const b of candidate.slice(1)) tmp.applyBlock(b);
    this.blocks=candidate.map(b=>JSON.parse(JSON.stringify(b)));
    this.accounts=tmp.accounts; this.totalSupply=tmp.totalSupply; this.mempool=new Map();
    this.store.replaceBlocks(this.blocks); this.persist();
    return {height:this.height,tip:this.tip.hash};
  }
  mine(miner, limit=500) {
    const txs=[...this.mempool.values()].slice(0,limit);
    let nonce=0;
    while(true) {
      const b={version:1,chainId:this.cfg.chainId,height:this.height+1,previousHash:this.tip.hash,
        timestamp:Date.now(),nonce,difficulty:this.cfg.initialDifficulty,miner,transactions:txs};
      b.hash=blockHash(b);
      if(b.hash.startsWith("0".repeat(b.difficulty))) { this.applyBlock(b); return b; }
      nonce++;
    }
  }
}
