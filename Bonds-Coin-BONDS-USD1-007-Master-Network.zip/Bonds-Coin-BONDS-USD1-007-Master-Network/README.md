# Bonds Coin (BONDS) — Mainnet Candidate

Bonds Coin is a unified cryptocurrency project combining the functional roles of the supplied blockchain, privacy, ledger, wallet, DEX, and trading projects into one modular network.

## Current release

**BONDS Mainnet Candidate v1**

- Name: Bonds Coin
- Symbol: BONDS
- Decimals: 8
- Maximum supply: 100,000,000,000 BONDS
- Target value: $1.00 USD per BONDS
- Peg model: 1:1 redeemable reserve-backed
- Initial circulating supply: 0 BONDS until reserves are verified
- Chain ID: 1001
- Network ID: bonds-mainnet
- Consensus candidate: proof-of-work
- Runtime: Node.js 20+
- RPC: `127.0.0.1:8080`
- P2P: `0.0.0.0:19001`
- Persistent data: `data/mainnet/`

## Readiness foundation

The project now includes the supplied production-readiness package under `docs/readiness/` and the isolated no-value public-testnet reference under `testnet/`. These assets are structural safeguards and documentation; they do **not** activate mainnet issuance, reserves, custody, trading, or redemption.

The next-value layer also includes `packages/issuer/src/reserve.mjs`, a reserve-attestation policy boundary that maps verified USD reserve capacity to BONDS issuance capacity. It is deliberately evidence-gated: code cannot create real reserves or establish a legal redemption obligation.

## Start

```bash
npm start
```

Then:

```bash
curl http://127.0.0.1:8080/
curl http://127.0.0.1:8080/blocks
```

Create a separate wallet:

```bash
npm run wallet -- wallet.json
```

## Mainnet architecture

```text
                 ┌─────────────────────────┐
                 │     BONDS Web Wallet     │
                 └────────────┬────────────┘
                              │ RPC
                 ┌────────────▼────────────┐
                 │       BONDS Node        │
                 │ RPC + Mempool + P2P     │
                 └───────┬────────┬────────┘
                         │        │
                   ┌─────▼───┐ ┌──▼────────┐
                   │ Ledger  │ │ Consensus │
                   └─────┬───┘ └──┬────────┘
                         │        │
                   ┌─────▼────────▼─────┐
                   │ Persistent Storage │
                   └────────────────────┘
```

The $1 target is a reserve/redemption policy, not an automatically guaranteed market price. The DEX, privacy, wallet, and trading layers remain modular so consensus-critical code is not accidentally coupled to application features.

## Critical warning

This is a **mainnet candidate**, not a claim that a public mainnet is safe for real funds today. The remaining protocol/security gates are documented in `docs/MAINNET_STATUS.md` and `docs/MAINNET_CHECKLIST.md`.

Do not put real money, production private keys, or exchange credentials into this development candidate before independent security review.

## Production engineering controls

Version 1.3 adds persistent issuer action state, quorum-gated issuance, authenticated settlement confirmations, redemption-to-burn gating, tamper-evident audit logs, and adversarial production-control tests. These controls are integration-ready but do not claim that a real custodian, bank, auditor, or reserve account is connected.
