# Bonds Bank Tokenized USD Credit — Legal Issuer Blueprint

**Status: planning artifact; not a formed legal entity and not legal advice.**

Recommended architecture to be confirmed by U.S. regulatory counsel:

1. A legally formed issuer entity holds the contractual obligations to token holders.
2. A separately regulated depository/custodian holds the backing USD and provides independently verifiable statements/attestations.
3. A contracted KYC/AML provider performs identity and sanctions screening before a wallet becomes eligible.
4. Production signing keys are held in an institutional HSM/KMS under dual-control/quorum procedures.
5. The issuer maintains books and records reconciling USD liabilities, token supply, pending redemptions, and custody balances.
6. Legal counsel determines whether the product is a tokenized deposit, stablecoin, stored-value instrument, or another regulated product and identifies the required licenses/partnerships.
7. No customer minting is permitted until the issuer, custody arrangement, compliance program, and regulatory permissions are documented and approved.

Required external evidence: certificate of formation, governing documents, regulatory/partner opinion, custody agreement, reserve account confirmation, AML/KYC program approval, and board/authorized-person resolutions.
