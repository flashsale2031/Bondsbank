export class ProductionProviderRegistry {
  constructor({ bankLedger, custody, kyc, signer }) {
    for (const [name, value] of Object.entries({bankLedger,custody,kyc,signer})) {
      if (!value) throw new Error(`missing production provider: ${name}`);
    }
    this.bankLedger = bankLedger; this.custody = custody; this.kyc = kyc; this.signer = signer;
  }
  async preflight() {
    const reserve = await this.custody.getReserveEvidence();
    if (!reserve?.verified || reserve.currency !== 'USD') throw new Error('reserve evidence not verified');
    if (!Number.isSafeInteger(reserve.availableUsdMicros) || reserve.availableUsdMicros < 0) throw new Error('invalid reserve amount');
    return { ok:true, providerIds:{ bankLedger:this.bankLedger.providerId ?? 'configured', custody:this.custody.providerId ?? 'configured', kyc:this.kyc.providerId ?? 'configured', signer:this.signer.keyId ?? 'configured' }, reserve };
  }
}
