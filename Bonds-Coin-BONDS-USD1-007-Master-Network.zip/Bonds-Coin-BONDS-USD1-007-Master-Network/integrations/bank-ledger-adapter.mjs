import crypto from 'node:crypto';

export class BankLedgerAdapter {
  constructor({ providerId, verifyDeposit, verifyPayout }) {
    if (!providerId || typeof verifyDeposit !== 'function' || typeof verifyPayout !== 'function') {
      throw new Error('providerId and verification functions are required');
    }
    this.providerId = providerId;
    this.verifyDeposit = verifyDeposit;
    this.verifyPayout = verifyPayout;
  }

  async verifyClientDeposit({ depositId, accountRef, amountUsdMicros, identityRef }) {
    if (!depositId || !accountRef || !identityRef || !Number.isSafeInteger(amountUsdMicros) || amountUsdMicros <= 0) {
      throw new Error('invalid deposit request');
    }
    const result = await this.verifyDeposit({ providerId: this.providerId, depositId, accountRef, amountUsdMicros, identityRef });
    if (!result?.verified || result.amountUsdMicros !== amountUsdMicros) throw new Error('deposit not verified 1:1');
    return { ...result, depositId, amountUsdMicros, verificationHash: crypto.createHash('sha256').update(JSON.stringify(result)).digest('hex') };
  }

  async verifyRedemptionPayout({ redemptionId, accountRef, amountUsdMicros }) {
    if (!redemptionId || !accountRef || !Number.isSafeInteger(amountUsdMicros) || amountUsdMicros <= 0) throw new Error('invalid payout request');
    const result = await this.verifyPayout({ providerId: this.providerId, redemptionId, accountRef, amountUsdMicros });
    if (!result?.settled || result.amountUsdMicros !== amountUsdMicros) throw new Error('payout not settled 1:1');
    return { ...result, redemptionId, amountUsdMicros, settlementHash: crypto.createHash('sha256').update(JSON.stringify(result)).digest('hex') };
  }
}
