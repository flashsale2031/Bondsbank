import crypto from 'node:crypto';

export class HttpKmsSigner {
  constructor({ baseUrl, apiKey, keyId, timeoutMs = 5000 }) {
    if (!baseUrl || !apiKey || !keyId) throw new Error('KMS signer requires baseUrl, apiKey, keyId');
    this.baseUrl = baseUrl.replace(/\/$/, ''); this.apiKey = apiKey; this.keyId = keyId; this.timeoutMs = timeoutMs;
  }
  async sign(payload) {
    const digest = crypto.createHash('sha256').update(payload).digest('hex');
    const controller = new AbortController(); const timer = setTimeout(() => controller.abort(), this.timeoutMs);
    try {
      const res = await fetch(`${this.baseUrl}/v1/keys/${encodeURIComponent(this.keyId)}/sign`, {
        method:'POST', signal:controller.signal,
        headers:{'content-type':'application/json','authorization':`Bearer ${this.apiKey}`},
        body:JSON.stringify({digest,algorithm:'ed25519'})
      });
      if (!res.ok) throw new Error(`KMS HTTP ${res.status}`);
      const result = await res.json();
      if (!result.signature) throw new Error('KMS response missing signature');
      return result;
    } finally { clearTimeout(timer); }
  }
}
