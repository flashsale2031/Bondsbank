export class HttpBankLedgerProvider {
  constructor({ baseUrl, apiKey, timeoutMs = 5000 }) {
    if (!baseUrl || !apiKey) throw new Error('bank ledger provider requires baseUrl and apiKey');
    this.baseUrl = baseUrl.replace(/\/$/, '');
    this.apiKey = apiKey;
    this.timeoutMs = timeoutMs;
  }
  async #post(path, body) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);
    try {
      const res = await fetch(`${this.baseUrl}${path}`, {
        method: 'POST', signal: controller.signal,
        headers: {'content-type':'application/json','authorization':`Bearer ${this.apiKey}`},
        body: JSON.stringify(body)
      });
      if (!res.ok) throw new Error(`bank ledger HTTP ${res.status}`);
      return await res.json();
    } finally { clearTimeout(timer); }
  }
  verifyDeposit(input) { return this.#post('/v1/deposits/verify', input); }
  verifyPayout(input) { return this.#post('/v1/payouts/verify', input); }
}
