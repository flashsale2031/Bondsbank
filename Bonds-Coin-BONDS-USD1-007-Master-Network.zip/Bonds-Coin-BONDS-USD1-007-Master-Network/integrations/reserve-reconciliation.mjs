export function reconcileTokenizedUsd({ verifiedReserveUsdMicros, circulatingUsdMicros, pendingRedemptionsUsdMicros }) {
  for (const v of [verifiedReserveUsdMicros, circulatingUsdMicros, pendingRedemptionsUsdMicros]) {
    if (!Number.isSafeInteger(v) || v < 0) throw new Error('reserve values must be non-negative safe integers');
  }
  const committed = circulatingUsdMicros + pendingRedemptionsUsdMicros;
  return {
    verifiedReserveUsdMicros,
    committedUsdMicros: committed,
    availableMintCapacityUsdMicros: Math.max(0, verifiedReserveUsdMicros - committed),
    covered: verifiedReserveUsdMicros >= committed,
    coverageRatio: committed === 0 ? null : verifiedReserveUsdMicros / committed,
  };
}
