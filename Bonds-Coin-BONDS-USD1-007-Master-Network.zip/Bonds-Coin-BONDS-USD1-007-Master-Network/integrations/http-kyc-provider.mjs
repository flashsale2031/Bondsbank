export class HttpKycProvider {
  constructor({ baseUrl, apiKey, timeoutMs = 5000 }) {
    if (!baseUrl || !apiKey) throw new Error('KYC provider requires baseUrl and apiKey');
    this.baseUrl = baseUrl.replace(/\/$/, ''); this.apiKey = apiKey; this.timeoutMs = timeoutMs;
  }
  async verifyIdentity({ identityRef, walletAddress }) {
    const controller = new AbortController(); const timer = setTimeout(() => controller.abort(), this.timeoutMs);
    try {
      const res = await fetch(`${this.baseUrl}/v1/identities/verify`, {
        method:'POST', signal:controller.signal,
        headers:{'content-type':'application/json','authorization':`Bearer ${this.apiKey}`},
        body:JSON.stringify({identityRef,walletAddress})
      });
      if (!res.ok) throw new Error(`KYC provider HTTP ${res.status}`);
      const result = await res.json();
      if (!result.verified) throw new Error('identity not verified');
      return result;
    } finally { clearTimeout(timer); }
  }
}
