export class HttpCustodyProvider {
  constructor({ baseUrl, apiKey, timeoutMs = 5000 }) {
    if (!baseUrl || !apiKey) throw new Error('custody provider requires baseUrl and apiKey');
    this.baseUrl = baseUrl.replace(/\/$/, ''); this.apiKey = apiKey; this.timeoutMs = timeoutMs;
  }
  async #get(path) {
    const controller = new AbortController(); const timer = setTimeout(() => controller.abort(), this.timeoutMs);
    try {
      const res = await fetch(`${this.baseUrl}${path}`, {headers:{authorization:`Bearer ${this.apiKey}`}, signal: controller.signal});
      if (!res.ok) throw new Error(`custody HTTP ${res.status}`); return await res.json();
    } finally { clearTimeout(timer); }
  }
  getReserveEvidence() { return this.#get('/v1/reserves/current'); }
  getAccountStatus(accountRef) { return this.#get(`/v1/accounts/${encodeURIComponent(accountRef)}`); }
}
