import test from 'node:test';
import assert from 'node:assert/strict';
import {RateLimiter,bearerAuthorized,metricsSnapshot} from '../packages/production/src/rpc-ops.mjs';

test('RPC bearer authorization is constant-time compatible and rejects malformed tokens',()=>{
 const req={headers:{authorization:'Bearer secret-token'}};
 assert.equal(bearerAuthorized(req,'secret-token'),true);
 assert.equal(bearerAuthorized(req,'other'),false);
 assert.equal(bearerAuthorized({headers:{}},'secret-token'),false);
});

test('RPC rate limiter blocks excess requests in a window',()=>{
 const r=new RateLimiter({windowMs:1000,max:2});
 assert.equal(r.allow('a',1000),true); assert.equal(r.allow('a',1001),true); assert.equal(r.allow('a',1002),false); assert.equal(r.allow('a',2000),true);
});

test('metrics snapshot exposes operational counters',()=>{
 const m=metricsSnapshot({requests:5,rejected:2,errors:1,startedAt:Date.now()-2500});
 assert.deepEqual(m.requests_total,5); assert.deepEqual(m.requests_rejected_total,2); assert.deepEqual(m.errors_total,1); assert.ok(m.uptime_seconds>=2);
});
