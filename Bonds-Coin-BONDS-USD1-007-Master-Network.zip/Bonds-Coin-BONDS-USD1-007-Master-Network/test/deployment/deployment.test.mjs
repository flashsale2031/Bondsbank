import test from 'node:test'; import assert from 'node:assert/strict'; import fs from 'node:fs'; import path from 'node:path';
const root=path.resolve(import.meta.dirname,'../..');
test('deployment assets are present and secret-free',()=>{for(const f of ['deploy/Dockerfile','deploy/docker-compose.yml','deploy/.env.example','deploy/nginx/bonds.conf','deploy/systemd/bonds-node.service','.github/workflows/release.yml']) assert.equal(fs.existsSync(path.join(root,f)),true,f);const compose=fs.readFileSync(path.join(root,'deploy/docker-compose.yml'),'utf8');assert.match(compose,/BONDS_RPC_TOKEN/);assert.doesNotMatch(compose,/Bearer\s+[A-Za-z0-9]{20,}/)});
test('rollback script requires an explicit backup target',()=>assert.match(fs.readFileSync(path.join(root,'scripts/ops/rollback.mjs'),'utf8'),/usage: node scripts\/ops\/rollback\.mjs/));
test('release verifier exists',()=>assert.equal(fs.existsSync(path.join(root,'scripts/verify-release.mjs')),true));
