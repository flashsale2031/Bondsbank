import test from "node:test";
import assert from "node:assert/strict";
import {walletNew, txSign, txVerify, address, blockHash} from "../node/protocol.mjs";

test("wallet addresses are deterministic",()=>{
  const w=walletNew(); assert.equal(w.address,address(w.publicKey));
});
test("Ed25519 transaction signatures verify",()=>{
  const a=walletNew(), b=walletNew();
  const tx=txSign(a,{chainId:1001,network:"bonds-mainnet",from:a.address,to:b.address,
    amount:"100",fee:"1",nonce:0,timestamp:1,publicKey:a.publicKey});
  assert.equal(txVerify(tx),true);
  tx.amount="101"; assert.equal(txVerify(tx),false);
});
test("block hashes are deterministic",()=>{
  const b={version:1,chainId:1001,height:1,previousHash:"0".repeat(64),
    timestamp:1,nonce:0,difficulty:1,miner:"Babc",transactions:[]};
  assert.equal(blockHash(b),blockHash(b));
});
