import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path';
import {createSigner, signApproval} from '../packages/control/src/quorum.mjs';
import {KeyRegistry} from '../packages/production/src/key-registry.mjs';
import {OperationGate} from '../packages/production/src/operation-gate.mjs';
import {DurableReplayGuard} from '../packages/production/src/durable-replay.mjs';
import {evaluateProductionReadiness} from '../packages/production/src/readiness-gate.mjs';

test('operation pause persists and blocks',()=>{ const d=fs.mkdtempSync(path.join(os.tmpdir(),'bonds-gate-')); let g=new OperationGate(d); g.pause('incident'); assert.throws(()=>g.assertOpen(),/paused/); g=new OperationGate(d); assert.equal(g.status().paused,true); g.resume(); assert.equal(g.assertOpen(),true); });
test('durable replay survives restart',()=>{ const d=fs.mkdtempSync(path.join(os.tmpdir(),'bonds-replay-')); let r=new DurableReplayGuard(d,'settlement'); r.claim('x'); r=new DurableReplayGuard(d,'settlement'); assert.equal(r.has('x'),true); assert.throws(()=>r.claim('x'),/replay/); });
test('readiness gate reports external blockers',()=>{ const r=evaluateProductionReadiness({config:{issuerAddress:'REPLACE_WITH_AUDITED_ISSUER_ADDRESS'},reserveValid:false,custodyConfigured:false,keysAudited:false,externalAuditPassed:false,testnetPassed:false}); assert.equal(r.ready,false); assert.equal(r.blockers.length,6); });
test('key registry accepts unique valid keys and rejects duplicates',()=>{ const d=fs.mkdtempSync(path.join(os.tmpdir(),'bonds-keys-')); const k=createSigner(); const r=new KeyRegistry(d); r.add({id:'issuer-1',publicKeyPem:k.publicKey,role:'issuer'}); assert.equal(r.active('issuer').length,1); assert.throws(()=>r.add({id:'issuer-1',publicKeyPem:k.publicKey,role:'issuer'}),/already exists/); });
