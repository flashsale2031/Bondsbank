import test from 'node:test';
import assert from 'node:assert/strict';
import { reconcileTokenizedUsd } from '../../integrations/reserve-reconciliation.mjs';
import { BankLedgerAdapter } from '../../integrations/bank-ledger-adapter.mjs';

test('strict 1:1 reserve capacity', () => {
  const r = reconcileTokenizedUsd({ verifiedReserveUsdMicros: 100_000_000, circulatingUsdMicros: 90_000_000, pendingRedemptionsUsdMicros: 5_000_000 });
  assert.equal(r.covered, true);
  assert.equal(r.availableMintCapacityUsdMicros, 5_000_000);
});

test('reserve deficit is never treated as covered', () => {
  const r = reconcileTokenizedUsd({ verifiedReserveUsdMicros: 99_000_000, circulatingUsdMicros: 100_000_000, pendingRedemptionsUsdMicros: 0 });
  assert.equal(r.covered, false);
  assert.equal(r.availableMintCapacityUsdMicros, 0);
});

test('bank deposit verification must match exact amount', async () => {
  const adapter = new BankLedgerAdapter({
    providerId: 'test-bank',
    verifyDeposit: async () => ({ verified: true, amountUsdMicros: 1_000_000 }),
    verifyPayout: async () => ({ settled: true, amountUsdMicros: 1_000_000 }),
  });
  const result = await adapter.verifyClientDeposit({ depositId: 'd1', accountRef: 'acct', amountUsdMicros: 1_000_000, identityRef: 'kyc-1' });
  assert.equal(result.amountUsdMicros, 1_000_000);
});

test('bank payout verification must match exact amount', async () => {
  const adapter = new BankLedgerAdapter({
    providerId: 'test-bank',
    verifyDeposit: async () => ({ verified: true, amountUsdMicros: 1_000_000 }),
    verifyPayout: async () => ({ settled: true, amountUsdMicros: 1_000_000 }),
  });
  const result = await adapter.verifyRedemptionPayout({ redemptionId: 'r1', accountRef: 'acct', amountUsdMicros: 1_000_000 });
  assert.equal(result.amountUsdMicros, 1_000_000);
});
