import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const token = fs.readFileSync(new URL('../../contracts/BondsBankUSDToken.sol', import.meta.url), 'utf8');
const dvp = fs.readFileSync(new URL('../../contracts/BondsBankAtomicDvP.sol', import.meta.url), 'utf8');

test('token contract exposes strict reserve/mint/burn surface', () => {
  for (const marker of ['verifiedReserveUsdMicros', 'mintFromVerifiedDeposit', 'requestRedemption', 'settleAndBurn', 'processedDepositIds', 'processedSettlementIds', 'kycApproved']) {
    assert.match(token, new RegExp(marker));
  }
});

test('atomic DvP contract has bilateral execute path', () => {
  assert.match(dvp, /function execute\(bytes32 tradeId\)/);
  assert.match(dvp, /transferFrom\(t\.buyer, t\.seller, t\.cashAmount\)/);
  assert.match(dvp, /transferFrom\(t\.seller, t\.buyer, t\.assetAmount\)/);
});
