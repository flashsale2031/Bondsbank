import test from "node:test";
import assert from "node:assert/strict";
import { createSigner, signApproval, assertQuorum } from "../packages/control/src/quorum.mjs";

test("issuer action requires quorum", () => {
  const a = createSigner(), b = createSigner();
  const registry = new Map([["a", {publicKey:a.publicKey}], ["b", {publicKey:b.publicKey}]]);
  const action = {type:"mint", amountBondsAtomic:"100000000", attestationDigest:"abc"};
  const aa = signApproval(action, "a", a.privateKey);
  assert.throws(() => assertQuorum(action, [aa], registry, 2), /quorum/);
  const bb = signApproval(action, "b", b.privateKey);
  assert.deepEqual(assertQuorum(action, [aa, bb], registry, 2).sort(), ["a","b"]);
});
