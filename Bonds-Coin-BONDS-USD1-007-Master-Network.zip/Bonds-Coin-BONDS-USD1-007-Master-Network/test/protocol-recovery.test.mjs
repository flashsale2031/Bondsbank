import test from 'node:test'; import assert from 'node:assert/strict'; import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path';
import {writeSnapshot,loadSnapshot,verifyChainBlocks,cumulativeWork} from '../packages/protocol/recovery.mjs';
import {makeGenesis,blockHash} from '../node/protocol.mjs';
const cfg={chainId:1001};
test('snapshot integrity survives and detects tamper',()=>{const d=fs.mkdtempSync(path.join(os.tmpdir(),'bonds-snap-'));const g=makeGenesis('Btest');const chain={height:0,tip:g.block,accounts:new Map([['Btest',{balance:'0',nonce:0}]]),totalSupply:0n};const f=writeSnapshot(d,chain);assert.equal(loadSnapshot(f).height,0);fs.appendFileSync(f,'tamper');assert.throws(()=>loadSnapshot(f),/(integrity|Unexpected non-whitespace)/)});
test('chain verification rejects predecessor corruption',()=>{const g=makeGenesis('Btest');assert.equal(verifyChainBlocks([g.block],cfg),true);const bad={...g.block,previousHash:'f'.repeat(64)};bad.hash=blockHash(bad);assert.throws(()=>verifyChainBlocks([bad],cfg),/genesis predecessor/)});
test('cumulative work favors higher difficulty',()=>{assert(cumulativeWork([{difficulty:4}])>cumulativeWork([{difficulty:3}]))});
