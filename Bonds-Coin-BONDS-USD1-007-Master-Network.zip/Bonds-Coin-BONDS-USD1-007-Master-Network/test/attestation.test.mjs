import test from "node:test";
import assert from "node:assert/strict";
import { createAttestationKey, signAttestation, verifyAttestation, validateAttestation } from "../packages/issuer/src/attestation.mjs";
import { reconcileReserve } from "../packages/issuer/src/reserve.mjs";

test("reserve attestation is signed and reconciles", () => {
  const k = createAttestationKey();
  const a = {id:"att-1", asOf:Date.now(), availableUsdAtomic:"1000000", custodian:"custodian", source:"independent-attestation", expiresAt:Date.now()+60_000};
  const sig = signAttestation(a, k.privateKey);
  assert.equal(verifyAttestation(a, sig, k.publicKey), true);
  validateAttestation(a);
  const result = reconcileReserve({issuedBondsAtomic:100_000_000n, attestation:{...a, verified:true}});
  assert.equal(result.status, "reconciled");
  assert.equal(result.reserveRatioBps, "10000");
});
