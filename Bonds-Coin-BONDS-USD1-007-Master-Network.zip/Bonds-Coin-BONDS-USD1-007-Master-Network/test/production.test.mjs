import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { AuditLog } from '../packages/production/src/audit.mjs';
import { productionReconciliation } from '../packages/production/src/reconciliation.mjs';
import { createSigner, signApproval } from '../packages/control/src/quorum.mjs';
import { IssuerState } from '../packages/production/src/issuer-state.mjs';
import { createAttestationKey, signAttestation, attestationDigest } from '../packages/issuer/src/attestation.mjs';

test('tamper-evident audit log verifies',()=>{ const d=fs.mkdtempSync(path.join(os.tmpdir(),'bonds-audit-')); const a=new AuditLog(d); a.append('one',{x:1}); a.append('two'); assert.equal(a.verify().valid,true); fs.appendFileSync(path.join(d,'audit.jsonl'),'corrupt\n'); assert.equal(a.verify().valid,false); });

test('production reconciliation blocks stale reserve evidence',()=>{ const now=100000; const att={id:'a',asOf:1,availableUsdAtomic:'1000000',custodian:'c',source:'s',expiresAt:99999,verified:true}; const r=productionReconciliation({issuedBondsAtomic:0n,attestation:att},now); assert.equal(r.status,'blocked'); });

test('issuer mint state requires quorum before execution',async()=>{ const d=fs.mkdtempSync(path.join(os.tmpdir(),'bonds-issuer-')); const a=createSigner(),b=createSigner(); const reg=new Map([['a',{publicKey:a.publicKey}],['b',{publicKey:b.publicKey}]]); const s=new IssuerState({dir:d,issuerAddress:'Bissuer',quorumThreshold:2,signerRegistry:reg}); const k=createAttestationKey(); const att={id:'att',asOf:Date.now(),availableUsdAtomic:'1000000',custodian:'c',source:'s',expiresAt:Date.now()+60000}; s.registerAttestation(att,signAttestation(att,k.privateKey),k.publicKey); const ad=attestationDigest(att); s.proposeMint({id:'m1',to:'Bholder',amountBondsAtomic:'100000000',attestationDigest:ad}); const action=s.state.actions.m1.action; const aa=signApproval(action,'a',a.privateKey), bb=signApproval(action,'b',b.privateKey); s.approveMint('m1',[aa,bb]); assert.equal(s.state.actions.m1.status,'approved'); s.markExecuted('m1','tx1'); assert.equal(s.state.actions.m1.status,'executed'); });

test('settlement adapter rejects invalid signatures and replays', async()=>{
  const { createAttestationKey } = await import('../packages/issuer/src/attestation.mjs');
  const { signSettlement, SettlementAdapter } = await import('../packages/production/src/settlement-adapter.mjs');
  const k=createAttestationKey(); const adapter=new SettlementAdapter({provider:'custodian-adapter',publicKey:k.publicKey});
  const m={id:'s1',amountUsdAtomic:'1000000',destination:'bank-ref',kind:'usd-payout',createdAt:1}; const sig=signSettlement(m,k.privateKey); assert.equal(adapter.accept(m,sig).id,'s1'); assert.throws(()=>adapter.accept(m,sig),/replay/);
});

test('burn is blocked until USD settlement is recorded', async()=>{
  const { MintBurnController } = await import('../packages/production/src/mint-burn.mjs');
  const c=new MintBurnController({issuerAddress:'Bissuer'}); const r=c.createRedemption({holder:'Bholder',amountBondsAtomic:100000000n,destination:'bank'}); c.approveRedemption(r.id); assert.throws(()=>c.authorizeBurn(r.id),/settlement/); c.recordUsdSettlement(r.id,{id:'s1',amountUsdAtomic:'1000000'}); const b=c.authorizeBurn(r.id); assert.equal(b.amountBondsAtomic,'100000000'); c.markBurnExecuted(b.id,'tx-burn-1'); assert.equal(c.burns.get(b.id).status,'executed');
});
