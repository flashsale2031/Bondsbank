import test from "node:test";
import assert from "node:assert/strict";
import { RedemptionBook } from "../packages/settlement/src/redemption.mjs";

test("redemption follows pending -> approved -> settled", () => {
  const book = new RedemptionBook({issuerAddress:"Bissuer"});
  const r = book.create({holder:"Bholder", amountBondsAtomic:100_000_000n, destination:"usd-bank-account"});
  assert.equal(book.approve(r.id).status, "approved");
  assert.equal(book.settle(r.id, "bank-ref-1").status, "settled");
  assert.throws(() => book.cancel(r.id), /settled/);
});

test("redemption cannot settle without approval or settlement reference", () => {
  const book = new RedemptionBook({issuerAddress:"Bissuer"});
  const r = book.create({holder:"Bholder", amountBondsAtomic:1n, destination:"usd-bank-account"});
  assert.throws(() => book.settle(r.id, "x"), /approved/);
  book.approve(r.id);
  assert.throws(() => book.settle(r.id, ""), /settlement reference/);
});
