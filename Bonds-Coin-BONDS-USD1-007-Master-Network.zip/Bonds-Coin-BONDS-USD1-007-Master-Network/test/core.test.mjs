import test from "node:test";
import assert from "node:assert/strict";
import { walletNew, txSign, txVerify, address, makeGenesis } from "../node/protocol.mjs";
import { Chain } from "../node/chain.mjs";

class MemoryStore {
  constructor() { this.blocks = []; this.state = null; }
  loadBlocks() { return this.blocks; }
  appendBlock(b) { this.blocks.push(b); }
  loadState() { return this.state; }
  saveState(s) { this.state = JSON.parse(JSON.stringify(s)); }
}

test("BONDS mainnet genesis starts with zero supply", () => {
  const alice = walletNew();
  const chain = new Chain({
    chainId: 1001, network: "bonds-mainnet", maxBlockBytes: 2_000_000,
    initialDifficulty: 0, issuerAddress: alice.address
  }, new MemoryStore(), makeGenesis(alice.address));
  assert.equal(chain.totalSupply, 0n);
});

test("signed transfer verifies", () => {
  const a = walletNew(), b = walletNew();
  const tx = txSign(a, {chainId:1001, network:"bonds-mainnet", type:"transfer",
    from:a.address,to:b.address,amount:"1",fee:"0",nonce:0,timestamp:1,publicKey:a.publicKey});
  assert.equal(txVerify(tx), true);
  assert.equal(address(a.publicKey), a.address);
});
