import test from "node:test";
import assert from "node:assert/strict";
import { assertMintCovered, reserveCapacityBondsAtomic } from "../packages/issuer/src/reserve.mjs";

test("reserve capacity maps one USD to one BONDS", () => {
  assert.equal(reserveCapacityBondsAtomic(1_000_000n), 100_000_000n);
});

test("mint requires verified, unexpired reserve evidence", () => {
  const state = {
    issuedBondsAtomic: 0n,
    attestation: {
      id: "att-1", asOf: 1, verified: true,
      availableUsdAtomic: 2_000_000n,
      custodian: "qualified-custodian",
      source: "independent-attestation",
      expiresAt: 2_000
    }
  };
  assert.doesNotThrow(() => assertMintCovered(state, 100_000_000n, 1_000));
  assert.throws(() => assertMintCovered({...state, attestation: {...state.attestation, verified: false}}, 1n, 1_000));
  assert.throws(() => assertMintCovered(state, 300_000_000n, 1_000));
  assert.throws(() => assertMintCovered(state, 1n, 3_000));
});
