import test from 'node:test';
import assert from 'node:assert/strict';
import { HttpBankLedgerProvider } from '../../integrations/http-bank-ledger-provider.mjs';
import { HttpCustodyProvider } from '../../integrations/http-custody-provider.mjs';
import { HttpKycProvider } from '../../integrations/http-kyc-provider.mjs';
import { HttpKmsSigner } from '../../integrations/http-kms-signer.mjs';

test('production providers require explicit endpoints and credentials', () => {
  assert.throws(() => new HttpBankLedgerProvider({}), /requires/);
  assert.throws(() => new HttpCustodyProvider({}), /requires/);
  assert.throws(() => new HttpKycProvider({}), /requires/);
  assert.throws(() => new HttpKmsSigner({}), /requires/);
});

test('KMS adapter hashes payload before remote signing', async () => {
  const original = global.fetch;
  global.fetch = async (_url, opts) => ({ ok:true, json:async()=>({signature:'sig', digest:JSON.parse(opts.body).digest}) });
  try {
    const kms = new HttpKmsSigner({baseUrl:'https://kms.example',apiKey:'x',keyId:'issuer'});
    const out = await kms.sign('payload');
    assert.equal(out.signature,'sig');
    assert.equal(out.digest.length,64);
  } finally { global.fetch = original; }
});
