import test from 'node:test';
import assert from 'node:assert/strict';
import {create007} from '../../network007/core.mjs';

const net=create007({
 chains:[
  {id:'evm:example',name:'Example EVM',adapter:'evm-adapter'},
  {id:'utxo:example',name:'Example UTXO',adapter:'utxo-adapter'}
 ],
 assets:[
  {id:'evm:example:USDX',chainId:'evm:example',symbol:'USDX'},
  {id:'utxo:example:COIN',chainId:'utxo:example',symbol:'COIN'}
 ],
 routes:[{id:'r1',fromAsset:'evm:example:USDX',toAsset:'utxo:example:COIN',feeBps:25}]
});

test('registers heterogeneous chains and assets',()=>{
 assert.equal(net.network.id,'007');
 assert.equal(net.chains.list().length,2);
 assert.equal(net.assets.list().length,2);
});

test('quotes and plans a conversion through verified route',()=>{
 const p=net.converter.plan({fromAsset:'evm:example:USDX',toAsset:'utxo:example:COIN',amount:'100000',recipient:'dest'});
 assert.equal(p.amountIn,'100000');
 assert.equal(p.amountOut,'99750');
 assert.equal(p.atomic,true);
});

test('fails closed without liquidity route',()=>{
 assert.throws(()=>net.converter.quote({fromAsset:'utxo:example:COIN',toAsset:'evm:example:USDX',amount:'1'}),/no executable liquidity route/);
});

test('bridge messages reject replay',()=>{
 const p=net.bridge.create({sourceChain:'evm:example',targetChain:'utxo:example',kind:'settlement'});
 assert.equal(net.bridge.accept(p).network,'007');
 assert.throws(()=>net.bridge.accept(p),/bridge message replay/);
});
