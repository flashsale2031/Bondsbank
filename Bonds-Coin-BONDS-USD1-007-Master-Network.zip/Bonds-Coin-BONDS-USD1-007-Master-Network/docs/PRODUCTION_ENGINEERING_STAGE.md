# Production Engineering Stage — Reserve, Issuance, Settlement

This stage adds the production control-plane foundation without pretending that a real bank, custodian, auditor, exchange, or payment provider is already connected.

## Implemented

- Persistent issuer action state for reserve-attested mint proposals.
- Ed25519 reserve-attestation verification.
- Quorum-gated mint approval.
- Explicit issued-supply input to every mint proposal; no implicit zero-supply reset.
- Tamper-evident hash-chained audit log.
- Production reserve reconciliation wrapper.
- Authenticated settlement-confirmation adapter with signature and replay checks.
- Redemption-to-USD-settlement-to-burn state boundary.
- Adversarial tests for audit tampering, stale reserves, invalid settlement signatures, settlement replay, quorum, and premature burns.

## External production dependencies still required

The repository intentionally does not embed real custody credentials, bank credentials, issuer private keys, exchange credentials, or fabricated reserve evidence. A production deployment must supply these through an HSM/secret manager and an independently controlled custodian/attestation source.

## Activation rule

A mainnet mint remains blocked unless the reserve evidence is valid and current and the issuer action receives the configured quorum. USD settlement must be authenticated before a redemption burn can be authorized.
