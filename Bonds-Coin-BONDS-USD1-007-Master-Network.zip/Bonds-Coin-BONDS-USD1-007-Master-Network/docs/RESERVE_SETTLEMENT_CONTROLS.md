# Reserve, Redemption, and Issuer-Control Layer

This stage adds the control-plane primitives needed between reserve evidence and public-value issuance.

## Flow

1. An independent custodian/attestation provider produces a reserve attestation.
2. The attestation is canonically serialized and Ed25519 signed.
3. The issuer reconciles verified reserve capacity against circulating BONDS.
4. A sensitive mint action is approved by the configured issuer quorum.
5. A holder creates a redemption request.
6. The issuer approves the request.
7. USD settlement occurs through an external banking/custody rail.
8. The settlement reference is recorded before the request becomes `settled`.
9. The corresponding BONDS must be burned by the issuer's audited production mint/burn system.

## Boundary

The repository does not claim to connect to a bank, custodian, payment network, or real reserve account. Those integrations require authenticated production credentials, contractual authority, reconciliation controls, and independent audit.
