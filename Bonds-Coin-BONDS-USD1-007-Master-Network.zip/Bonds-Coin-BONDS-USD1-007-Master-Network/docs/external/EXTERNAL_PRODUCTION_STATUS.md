# External Production Status

## Implemented in software

- Bank-ledger HTTPS adapter for deposit/payout verification.
- Custodian HTTPS adapter for reserve evidence and account status.
- KYC/AML HTTPS adapter for identity/wallet verification.
- Production HSM/KMS HTTPS signing boundary.
- Provider registry and reserve preflight.
- Legal issuer structure blueprint.
- Independent security-audit engagement package.

## Not represented as completed

The repository does **not** claim to have created or obtained:

- a regulated depository or custodian;
- a live bank account or bank API credential;
- a KYC/AML vendor contract or production credential;
- a production HSM/KMS tenant or issuer key ceremony;
- a legal entity, banking charter, money-transmitter license, or regulatory approval;
- an independent smart-contract/security audit.

Those items require real-world counterparties, legal professionals, regulated institutions, and independent auditors. The mainnet/customer-mint gate must remain disabled until objective evidence is attached to the launch ceremony.
