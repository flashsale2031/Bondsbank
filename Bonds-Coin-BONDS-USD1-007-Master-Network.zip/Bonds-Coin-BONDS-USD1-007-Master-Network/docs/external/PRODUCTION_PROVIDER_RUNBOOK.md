# Production Provider Integration Runbook

This project contains integration boundaries only. Real provider credentials must be supplied by the operator after contracts are executed with regulated providers.

Required live connections:
- regulated depository/custodian: reserve evidence + account status
- bank ledger: deposit verification + payout verification
- KYC/AML provider: identity/wallet eligibility + sanctions status
- institutional HSM/KMS: issuer transaction signing

Preflight sequence:
1. Verify legal issuer status.
2. Verify custody account and independent reserve evidence.
3. Verify KYC/AML contract and test-mode results.
4. Verify HSM/KMS key ceremony and public-key fingerprint.
5. Run provider preflight.
6. Reconcile reserve capacity with on-chain supply.
7. Execute external security audit and remediation.
8. Obtain launch quorum approval.
9. Enable customer minting only after all gates pass.
