# Smart-Contract Security Precheck

**Not an independent audit.** Generated as an engineering precheck for an external auditor.

Scope reviewed:
- `contracts/BondsBankUSDToken.sol`
- `contracts/BondsBankAtomicDvP.sol`
- provider boundaries under `integrations/`

Engineering checks completed:
- strict 1:1 reserve-capacity arithmetic;
- deposit and settlement replay protection;
- KYC/freeze gates;
- issuer/compliance/pause role boundaries;
- redemption pending accounting;
- atomic DvP execution surface;
- external provider credential boundaries;
- KMS signing boundary.

Independent auditor must reproduce the analysis, inspect compiler/dependency configuration, run static analysis and fuzz/property testing, review deployment bytecode, and issue a signed report. No production approval should rely on this document alone.
