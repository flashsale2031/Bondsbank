# Bonds Coin Readiness Package Manifest

> **No-value documentation and reference package.** This archive contains the Bonds Coin public-testnet reference source and the related readiness, security, provider-diligence, and controlled-operations documentation. It is not a production blockchain, issuer, stablecoin, reserve, custody service, wallet, exchange, redemption service, or investment product.

## Included scope

| Area | Included materials |
|---|---|
| Program documentation | Root README, API contract, deployment boundary, and Bonds Coin production-readiness design |
| Testnet reference | Node source, test suite, three-node local demo, and package metadata using only Node built-ins |
| Security and governance | Threat model, security policy, explicit mainnet boundary, and mainnet-readiness gates |
| Partner diligence | Provider-neutral engagement package, screening scope, and prospective-provider review list |
| Controlled operations | Reserve, redemption, custody, compliance, assurance, production-operations framework, and dry-run runbooks |

## Explicit exclusions

The archive contains no private keys, credentials, `.env` files, funded wallet data, customer data, account information, reserve assets, provider contracts, audit reports, customer onboarding records, sanctions screening records, live custody configuration, production deployment configuration, or issued BONDS balances.

## Operating limitation

The reference node retains `MAINNET_ACTIVATION.enabled = false`. Nothing in this archive authorizes issuance, an asserted $1 valuation, a reserve claim, custody, redemptions, transfers, trading, or mainnet activation. Those actions remain governed by the documented gates and require verified external evidence and action-specific authorization.
