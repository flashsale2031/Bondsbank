# BONDS Genesis Ceremony

Before announcing mainnet:

1. Freeze the exact source commit.
2. Freeze `config/mainnet.json`.
3. Decide and publish the genesis allocation.
4. Generate genesis keys in an offline ceremony.
5. Calculate and publish the genesis block hash.
6. Have multiple independent operators reproduce the hash.
7. Publish signed binaries and SHA-256 release hashes.
8. Start several independently operated seed nodes.
9. Run a public testnet with the same protocol.
10. Publish the genesis block and seed-node addresses.
11. Open the network only after independent verification.

The repository's first-start genesis behavior is intentionally a development convenience. It must **not** be used as the public genesis procedure.
