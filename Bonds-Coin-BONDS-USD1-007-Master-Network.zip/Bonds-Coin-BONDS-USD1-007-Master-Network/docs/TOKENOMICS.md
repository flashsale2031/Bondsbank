# BONDS Tokenomics

## Proposed fixed supply

**100,000,000,000 BONDS**

With 8 decimals, the maximum integer supply is:

`10,000,000,000,000,000,000` atomic units.

## Suggested genesis allocation

This is a governance proposal for the development network, not a claim that a mainnet allocation has been approved.

- 40% ecosystem/community
- 20% network/security incentives
- 15% development treasury
- 10% liquidity and market infrastructure
- 10% partnerships/grants
- 5% reserve

A production launch should replace percentages with a signed genesis specification and public vesting contracts/rules.

## Fees

The development ledger charges an explicit transaction fee. The current prototype routes fees to the block producer. A production network should specify:
- minimum relay fee
- dynamic fee policy
- fee burn vs. validator/miner reward
- anti-spam limits
- governance process for parameter changes
