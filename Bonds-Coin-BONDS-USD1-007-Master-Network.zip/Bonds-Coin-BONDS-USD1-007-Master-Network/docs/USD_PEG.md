# BONDS $1 USD Reserve-Backed Standard

BONDS is configured as a reserve-backed digital currency with a target redemption value of **$1.00 USD per BONDS**.

## What makes the $1 target credible

The blockchain cannot create a dollar value by itself. The $1 target becomes a real market peg only when an issuer:
1. Holds qualifying USD or USD-equivalent reserves for every circulating BONDS.
2. Mints BONDS only after reserve funding is verified.
3. Redeems BONDS for $1.00 under published terms.
4. Publishes regular reserve attestations and circulating-supply reports.
5. Uses an audited issuer key and strict mint/burn controls.

The code therefore starts with **zero circulating supply** instead of giving 100B BONDS to a genesis wallet.

## Native controls

- `mint`: issuer-only issuance; increases supply and must be backed off-chain.
- `burn`: destroys BONDS sent to the issuer; decreases supply.
- `transfer`: ordinary BONDS transfer.
- Maximum supply remains 100,000,000,000 BONDS.
- Target price is $1.00 USD.

## Important

`targetPriceUsd: "1.00"` is a protocol policy, not proof that BONDS currently trades at $1.00. A public launch requires the reserve, redemption, legal, custody, audit, oracle/attestation, and exchange/liquidity infrastructure described in the mainnet checklist.
