# BONDS Architecture

## Core principle

BONDS is a modular monorepo. The ledger is the source of truth. Wallets sign transactions; nodes validate and mine blocks; higher-level services consume ledger events.

### Layers

1. **Ledger / consensus**
   - signed account transactions
   - deterministic block hashing
   - proof-of-work development consensus
   - explicit upgrade boundary for production finality

2. **Privacy**
   - adapter boundary for zero-knowledge/shielded transfers
   - never mix privacy cryptography directly into ordinary transaction validation
   - production implementation must use audited libraries and formal protocol specifications

3. **Wallet**
   - key generation
   - address derivation
   - transaction signing
   - browser UI is intentionally not trusted with node private keys by default

4. **DEX / trading**
   - order matching and settlement are separate from consensus
   - strategy automation must operate with explicit risk limits
   - no exchange API secrets belong in source control

5. **Web**
   - static dashboard
   - GitHub Pages compatible
   - node API can be replaced with an authenticated production gateway

## Why not literally concatenate all repositories?

The supplied repositories implement different protocols. Copying their entire source trees into one executable would create conflicting consensus rules, duplicate wallets, incompatible build systems, and ambiguous licensing. BONDS instead integrates the *functional roles* behind stable interfaces. The original archives remain available to the project owner as upstream source material.
