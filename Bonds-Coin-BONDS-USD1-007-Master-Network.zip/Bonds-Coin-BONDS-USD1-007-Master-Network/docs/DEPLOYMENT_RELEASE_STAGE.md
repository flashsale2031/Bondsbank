# Deployment & Release Engineering Stage

This stage adds immutable deployment artifacts and operational upgrade/rollback boundaries.

## Included
- Docker image definition with non-root execution, read-only root filesystem, dropped Linux capabilities, and health checks.
- Compose deployment with persistent data volume and secret injection through environment configuration.
- TLS reverse-proxy boundary for Nginx; certificates remain external to the repository.
- systemd service definition with filesystem/process hardening.
- Backup rotation, pre-upgrade backup/readiness gate, and checksum-verified rollback tooling.
- Reproducible-release CI workflow and local release verification.

## Safety boundary
No production secrets, private keys, certificates, custody credentials, or issuer credentials are included. `BONDS_RPC_TOKEN` must be injected by the deployment environment or a secret manager.

## Upgrade
1. Build/tag an immutable image.
2. Run the complete test suite and release verification.
3. Take a fresh backup.
4. Run the readiness gate.
5. Deploy the new version with the same persistent data volume.
6. Confirm `/health/live`, `/health/ready`, metrics, and chain tip.
7. Keep the prior image available for rollback.

## Rollback
Stop the node before restoring state. Select a verified backup directory, run the rollback tool, then restart the exact previous image. A state rollback must be treated as an operational incident and reconciled with external settlement records before reopening writes.

## Production prerequisites
TLS certificates, DNS/firewall policy, secure secret storage/HSM, monitored host infrastructure, reserve/custody integrations, independent audit evidence, and a formal incident/change-management process remain external requirements.
