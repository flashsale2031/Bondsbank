# Security

This is a development/testnet project.

Before mainnet:
- independently audit transaction signing and serialization
- add persistent storage with crash recovery
- implement authenticated P2P networking
- implement replay protection and chain selection
- formally specify consensus/finality
- fuzz transaction/block parsing
- add deterministic state-transition tests
- threat-model wallets and browser storage
- add hardware-wallet support before significant custody
- run economic/DoS simulations
- obtain independent cryptography and smart-contract reviews
- establish reproducible builds and signed releases
- publish a responsible-disclosure policy

Never commit private keys, exchange API keys, seed phrases, or production secrets.
