# Tokenized USD Production Integration Matrix

| Layer | Software boundary | External dependency | Status |
|---|---|---|---|
| Bank ledger | `BankLedgerAdapter` | Real bank/custodian API | Not connected |
| Reserve | Signed reserve evidence | Independent custodian/auditor | Not verified |
| Identity | Wallet KYC allowlist | KYC/KYB + sanctions provider | Not connected |
| Issuance | `mintFromVerifiedDeposit` | Issuer/HSM authorization | Not production-enabled |
| Settlement | `BondsBankAtomicDvP` | Audited counterparty asset contract | Prototype |
| Redemption | `settleAndBurn` | Real ACH/wire settlement provider | Not connected |
| Cross-chain | Adapter boundary | Audited bridge/interoperability layer | Disabled |
| Monitoring | Existing operations stack | Production observability/SIEM | Requires deployment |
| Audit | Release evidence | Independent auditor | Outstanding |

No live credentials, reserve balances, banking account numbers, or private keys are included in this repository.
