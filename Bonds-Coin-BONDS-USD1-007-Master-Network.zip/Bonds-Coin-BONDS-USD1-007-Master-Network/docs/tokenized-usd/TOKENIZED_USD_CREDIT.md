# Bonds Bank Tokenized USD Credit (BBUSD)

## Purpose

This module implements the software boundary for a permissioned, tokenized-USD credit instrument with a strict 1:1 reserve loop:

`verified bank deposit -> mint BBUSD -> on-chain transfer/DvP -> redemption request -> verified USD payout -> burn BBUSD`

**BBUSD is not a bank deposit, insured deposit, or legally issued stablecoin merely because this code exists.** Bonds Bank must obtain the legal authority, banking/custody relationships, compliance program, and independent assurance required for the chosen structure before production issuance.

## Monetary invariant

Amounts use 6 decimal places (`1 BBUSD = 1 USD` at the contractual target). The issuer contract refuses to mint when:

`totalSupply + pendingRedemptions > independently verified reserve`

A deposit ID and settlement ID are single-use to prevent replay. Transfers require both sender and recipient to be KYC-approved and unfrozen.

## Issuance

1. Client completes KYC/KYB and links an approved wallet.
2. Client deposits USD into the designated reserve/depository account.
3. The bank/custodian adapter independently verifies the deposit amount.
4. The issuer records reserve evidence and deposit ID.
5. The issuer mints exactly the verified USD amount.

No software component in this repository fabricates a bank deposit or reserve confirmation.

## On-chain settlement

`BondsBankAtomicDvP.sol` provides a bilateral atomic delivery-versus-payment primitive. Both token legs are transferred in one transaction or the transaction reverts. A production deployment still requires audited asset contracts, participant controls, network selection, gas/fee policy, and legal agreements.

Cross-chain issuance/transfer is intentionally an adapter boundary. No bridge is trusted by default and no cross-chain minting is enabled by this repository.

## Redemption

1. Holder submits a unique redemption ID.
2. The issuer verifies the requested amount and compliance state.
3. The bank/settlement provider executes the USD payout.
4. The settlement adapter returns a unique settlement reference.
5. The issuer burns exactly the settled token amount.

The contract refuses a burn without a valid issuer-controlled settlement confirmation.

## Compliance controls

- KYC/KYB wallet allowlist
- Frozen-wallet control
- Issuer-only mint/burn settlement authority
- Pause control
- Deposit/settlement replay protection
- Reserve-capacity enforcement
- Audit/event trail

A real AML/KYC provider, sanctions screening, transaction monitoring, record retention, and case-management system must be connected before production use.

## 24/7 dashboard

The repository can expose operational request states 24/7, but bank settlement availability depends on the connected banking/custody provider. Do not represent an internal queue as guaranteed 24/7 banking settlement.

## Network selection

The contract is written for an EVM-compatible network. Public-chain deployment requires a separately audited deployment. A private/institutional network can use the same interface with an appropriate EVM execution environment or an equivalent token implementation.

## Production gates

Required before live issuance:

- Approved legal issuer structure and contractual terms
- Designated regulated bank/custodian account
- Live signed reserve evidence
- Audited issuer key/HSM or equivalent control
- Independent smart-contract/security audit
- KYC/AML/sanctions integration and documented controls
- Production monitoring, incident response, backup, and recovery
- Tested redemption operations
- Independent reconciliation of reserve and on-chain supply
