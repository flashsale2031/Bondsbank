# Tokenized USD Launch Boundary

This implementation creates the **software foundation** for Bonds Bank's tokenized USD credit loop. It does not create a bank account, a deposit, legal tender, an insured deposit, or live reserve assets.

## Required external activation evidence

1. Legal issuer structure and counsel sign-off.
2. Designated regulated depository/custodian account.
3. Live independently signed reserve evidence.
4. Production issuer key ceremony using approved HSM/KMS controls.
5. KYC/KYB, sanctions, transaction monitoring, and case-management integration.
6. Independent smart-contract/security audit with remediation and retest.
7. Successful end-to-end deposit, mint, transfer, DvP, redemption, and burn test using real counterparties.
8. Independent reconciliation proving `verified USD reserves >= token supply + committed redemptions`.

The mainnet readiness gate must remain closed until these artifacts exist and are independently verifiable.
