# BONDS Protocol v1

## Monetary unit

`1 BONDS = 100,000,000 atomic units`.

Maximum supply: `100,000,000,000 BONDS`.

All monetary values are integers. Floating point must never be used in consensus code.

## Transaction domain

A transaction commits to:
- chain ID
- network
- sender
- recipient
- amount
- fee
- nonce
- timestamp
- public key

Ed25519 signs the canonical representation.

## Block domain

A block commits to:
- protocol version
- chain ID
- height
- previous block hash
- timestamp
- nonce
- difficulty
- miner
- ordered transaction list

SHA-256 is used for block IDs and proof-of-work in this candidate.

## Production rule

Every consensus parameter must be versioned. Changing serialization, signature rules, monetary policy, or block validation rules requires an explicit protocol upgrade rather than an implicit software change.
