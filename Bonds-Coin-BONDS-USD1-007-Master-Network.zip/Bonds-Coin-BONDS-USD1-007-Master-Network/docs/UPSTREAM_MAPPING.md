# Upstream Mapping & Licensing

The supplied archive contains these projects:

- node-blockchain
- ironfish
- opentrade
- firo
- rippled
- monero-gui
- binance-trade-bot
- lets-build-a-blockchain

They are **not assumed to share one license**. Before copying upstream source into a distributable BONDS binary, preserve each project's license and notices and perform a dependency/license audit.

BONDS therefore uses a clean-room integration layer in this master repository. The projects inform module boundaries and capabilities:

- blockchain fundamentals → `packages/core`
- privacy/ZK → `packages/privacy`
- fast-finality/ledger concepts → consensus upgrade boundary
- DEX → `packages/dex`
- trading automation → `packages/trading`
- GUI wallet → `apps/web`

If upstream code is imported later, record the exact upstream commit, license, files copied, modifications, and attribution in this document.
