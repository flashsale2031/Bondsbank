# Production Operations Stage

This stage hardens the node's operational boundary without inventing external credentials.

## RPC security
- Read-only discovery and health endpoints remain available for monitoring.
- State-changing RPC methods require `Authorization: Bearer <BONDS_RPC_TOKEN>`.
- Tokens are supplied through the environment and are never stored in the repository.
- Per-client rate limiting is enforced before request handling.
- Every response receives an `x-request-id` for incident correlation.

## Health and metrics
- `GET /health/live` provides process liveness.
- `GET /health/ready` validates the local chain before reporting readiness.
- `GET /metrics` exposes operational counters as JSON for simple monitoring adapters.

## Backup and recovery
- `npm run ops:backup` creates a permission-restricted backup directory containing `chain.jsonl`, `state.json`, and a SHA-256 manifest.
- `npm run ops:restore-verify <backup-dir>` verifies backup integrity before restoration.
- Backup storage must be copied to independent infrastructure for real disaster recovery.

## Secret and HSM boundary
The repository intentionally does not contain production private keys. Operators should inject issuer/RPC secrets through a secret manager or HSM-backed signing service. The codebase accepts this boundary through environment configuration and the existing issuer/key-registry controls.

## Deployment controls
Production deployments should terminate TLS at a trusted edge, restrict RPC exposure to authorized networks, run the node as a non-root user, use filesystem permissions that prevent other users from reading wallet/state files, and retain immutable logs and off-host backups.

## Remaining external prerequisites
Operational software does not itself create banking, custody, audit, or regulatory authorization. Mainnet activation remains blocked until the existing readiness gate is satisfied by real external evidence.
