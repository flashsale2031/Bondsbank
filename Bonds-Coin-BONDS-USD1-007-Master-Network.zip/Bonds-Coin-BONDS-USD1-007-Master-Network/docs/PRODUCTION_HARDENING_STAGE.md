# Production Hardening Stage

This stage adds operational controls around the existing reserve/settlement control plane.

Implemented:
- durable replay protection for settlement/operator identifiers
- persistent emergency pause/resume gate
- issuer key registry foundation with key rotation signature validation
- explicit production-readiness gate that fails closed when custody, audited keys, external audit, reserve evidence, or testnet evidence are missing
- machine-readable readiness command (`npm run readiness`)

The readiness gate intentionally remains blocked until independent external dependencies are actually configured and verified. No bank, custodian, HSM, auditor, or private credential is fabricated by this repository.
