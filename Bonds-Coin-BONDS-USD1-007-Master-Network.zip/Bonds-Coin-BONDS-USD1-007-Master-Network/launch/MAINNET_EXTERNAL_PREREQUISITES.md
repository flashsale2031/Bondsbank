# Mainnet External Prerequisites

The following items cannot be created truthfully by source code alone:

- independent audit of the issuer address/control ceremony;
- live, independently verified USD reserve evidence;
- independent USD custody agreement and operational account;
- audited production issuer-key/HSM infrastructure;
- independent security audit and remediation retest;
- long-duration adversarial testnet evidence from independently operated infrastructure.

The project therefore keeps mainnet activation blocked until real external evidence is supplied and verified.
