# Independent Assurance Scope — Bonds USD1

Status: NOT COMMISSIONED / NOT AN AUDIT REPORT

This package defines the evidence an independent firm must review. It does not create an audit, assurance opinion, certification, SOC report, penetration test, or legal opinion.

## Required technical scope

1. Consensus and transaction validation.
2. Issuer mint/burn authorization and quorum logic.
3. Reserve-attestation verification and reconciliation.
4. Redemption settlement controls.
5. Ed25519 key management and production HSM/KMS boundary.
6. P2P authentication, replay protection, synchronization and reorganization safety.
7. Persistent state, snapshot and recovery logic.
8. RPC authentication, rate limiting and operational controls.
9. Container/systemd deployment boundary and supply-chain controls.
10. Adversarial testing, fuzzing and failure recovery.

## Required deliverables

- Signed engagement letter identifying the independent firm.
- Scope and methodology.
- Source/release hashes reviewed.
- Findings classified by severity.
- Remediation evidence.
- Independent retest of resolved findings.
- Final signed report.

The mainnet gate must remain closed until these artifacts are independently produced and verified.
