# BONDS USD1 Launch Evidence Package

This directory separates **software-generated evidence** from **external evidence that must come from independent parties**.

The candidate issuer address is intentionally labeled unaudited. No private production key is stored in this repository.

The testnet report records only evidence actually present in the project history: 9 testnet tests, 26 main-project tests, and 20,000 malformed-input fuzz iterations with zero uncaught crashes. It does **not** claim a long-duration testnet because the available history does not contain the required independent operational telemetry.

No live reserve, bank/custodian relationship, audit opinion, or production key ceremony is represented as completed by this package.
