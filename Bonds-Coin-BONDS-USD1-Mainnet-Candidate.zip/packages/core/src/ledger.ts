import { Block, Transaction, Account } from "../../shared/src/types.js";
import { sha256, verifyMessage } from "./crypto.js";

export const BONDS_DECIMALS = 8n;
export const UNIT = 100_000_000n;
export const MAX_SUPPLY = 100_000_000_000n * UNIT;
export const GENESIS_ALLOCATION = 100_000_000_000n * UNIT;

export function txPayload(tx: Transaction): string {
  return JSON.stringify({
    from: tx.from, to: tx.to, amount: tx.amount.toString(),
    fee: tx.fee.toString(), nonce: tx.nonce, timestamp: tx.timestamp,
    publicKey: tx.publicKey
  });
}

export function blockPayload(block: Omit<Block, "hash">): string {
  return JSON.stringify({
    height: block.height, previousHash: block.previousHash,
    timestamp: block.timestamp, nonce: block.nonce,
    difficulty: block.difficulty, miner: block.miner,
    transactions: block.transactions.map(tx => ({...tx, amount: tx.amount.toString(), fee: tx.fee.toString()}))
  });
}

export class Ledger {
  private readonly accounts = new Map<string, Account>();
  private readonly chain: Block[] = [];
  private totalIssued = 0n;

  constructor(genesisAddress: string) {
    const genesis: Block = {
      height: 0, previousHash: "0".repeat(64), timestamp: 0,
      nonce: 0, difficulty: 1, miner: "genesis", transactions: [],
      hash: ""
    };
    genesis.hash = sha256(blockPayload(genesis));
    this.chain.push(genesis);
    this.credit(genesisAddress, GENESIS_ALLOCATION);
  }

  private credit(address: string, amount: bigint) {
    const a = this.accounts.get(address) ?? { address, balance: 0n, nonce: 0 };
    a.balance += amount;
    this.accounts.set(address, a);
    this.totalIssued += amount;
  }

  getAccount(address: string): Account {
    return {...(this.accounts.get(address) ?? { address, balance: 0n, nonce: 0 })};
  }

  get height(): number { return this.chain.length - 1; }
  get latest(): Block { return this.chain[this.chain.length - 1]; }
  get supply(): bigint { return this.totalIssued; }
  get blocks(): Block[] { return [...this.chain]; }

  validateTransaction(tx: Transaction): string | null {
    if (tx.amount <= 0n) return "amount must be positive";
    if (tx.fee < 0n) return "fee cannot be negative";
    if (!tx.from || !tx.to) return "from/to required";
    if (addressFromPublicKey(tx.publicKey) !== tx.from) return "public key does not match sender";
    if (!verifyMessage(tx.publicKey, txPayload(tx), tx.signature)) return "invalid signature";
    const sender = this.accounts.get(tx.from);
    if (!sender) return "sender account not found";
    if (tx.nonce !== sender.nonce) return `invalid nonce: expected ${sender.nonce}`;
    if (sender.balance < tx.amount + tx.fee) return "insufficient balance";
    return null;
  }

  applyTransaction(tx: Transaction): void {
    const error = this.validateTransaction(tx);
    if (error) throw new Error(error);
    const sender = this.accounts.get(tx.from)!;
    sender.balance -= tx.amount + tx.fee;
    sender.nonce++;
    this.accounts.set(tx.from, sender);
    this.credit(tx.to, tx.amount);
    // Fees are not newly issued; they are transferred to the miner at block application time.
    this.totalIssued -= tx.amount;
    this.totalIssued += tx.amount;
  }

  mineBlock(transactions: Transaction[], miner: string, difficulty = 4): Block {
    for (const tx of transactions) {
      const error = this.validateTransaction(tx);
      if (error) throw new Error(error);
    }
    let nonce = 0;
    let block: Block;
    while (true) {
      block = {
        height: this.height + 1,
        previousHash: this.latest.hash,
        timestamp: Date.now(),
        nonce,
        difficulty,
        miner,
        transactions,
        hash: ""
      };
      block.hash = sha256(blockPayload(block));
      if (block.hash.startsWith("0".repeat(difficulty))) break;
      nonce++;
    }
    for (const tx of transactions) this.applyTransaction(tx);
    const fees = transactions.reduce((n, tx) => n + tx.fee, 0n);
    if (fees > 0n) {
      const minerAccount = this.accounts.get(miner) ?? {address: miner, balance: 0n, nonce: 0};
      minerAccount.balance += fees;
      this.accounts.set(miner, minerAccount);
    }
    this.chain.push(block);
    return block;
  }
}

export function addressFromPublicKey(publicKey: string): string {
  return "B" + sha256(publicKey).slice(0, 40);
}
