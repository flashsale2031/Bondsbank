# BONDS Mainnet Candidate — Status

This repository now contains a runnable **mainnet candidate node**, not merely a conceptual token.

Implemented:
- versioned network/chain ID
- deterministic transaction signatures
- replay-domain separation through network + chain ID
- persistent append-only block log
- persistent account state
- signed transaction mempool
- block validation
- proof-of-work validation
- peer TCP transport
- block synchronization messages
- JSON RPC
- local node wallet
- fee-only block producer economics (all 100B BONDS are allocated at genesis)
- separate testnet configuration
- dependency-free Node.js runtime

## Still required before a public-value mainnet

This is not a claim of cryptographic or economic production readiness. A real public mainnet requires independent review and additional protocol work, especially:
- canonical serialization specification and compatibility vectors
- difficulty retarget algorithm and timestamp rules
- peer authentication / anti-eclipse protections
- chain-work selection and safe reorganization handling
- database crash consistency and recovery testing
- mempool eviction/fee policy
- DoS controls
- deterministic state replay
- snapshot/checkpoint strategy
- wallet backup/recovery and hardware-wallet integration
- formal privacy protocol, if shielded transactions are enabled
- audited cryptography
- adversarial fuzzing and long-duration testnet
- genesis ceremony and immutable public genesis hash
- reproducible signed releases
- legal/compliance review appropriate to launch jurisdictions

The implementation intentionally refuses to pretend that these missing controls are solved.
