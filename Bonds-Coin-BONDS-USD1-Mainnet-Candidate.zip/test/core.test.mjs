import test from "node:test";
import assert from "node:assert/strict";
import { createWallet, createTransaction } from "../packages/core/dist/wallet.js";
import { Ledger, GENESIS_ALLOCATION, UNIT } from "../packages/core/dist/ledger.js";

test("BONDS genesis and signed transfer", () => {
  const alice = createWallet();
  const bob = createWallet();
  const ledger = new Ledger(alice.address);
  assert.equal(ledger.getAccount(alice.address).balance, GENESIS_ALLOCATION);

  const tx = createTransaction(alice, bob.address, 10n * UNIT, 1n, 0);
  ledger.mineBlock([tx], alice.address, 2);

  assert.equal(ledger.getAccount(bob.address).balance, 10n * UNIT);
  assert.equal(ledger.getAccount(alice.address).nonce, 1);
});

test("invalid signature is rejected", () => {
  const alice = createWallet(), bob = createWallet();
  const ledger = new Ledger(alice.address);
  const tx = createTransaction(alice, bob.address, 1n, 0n, 0);
  tx.to = alice.address;
  assert.throws(() => ledger.mineBlock([tx], alice.address, 1));
});
