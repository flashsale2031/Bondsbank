import net from "node:net";
import { blockHash } from "./protocol.mjs";

export class P2P {
  constructor(node,cfg){this.node=node;this.cfg=cfg;this.peers=new Set();}
  start(){
    this.server=net.createServer(s=>this.accept(s));
    this.server.listen(this.cfg.p2pPort,this.cfg.p2pHost);
  }
  accept(socket){
    socket.setEncoding("utf8"); let buf="";
    socket.on("data",d=>{buf+=d;let i;while((i=buf.indexOf("\n"))>=0){const line=buf.slice(0,i);buf=buf.slice(i+1);this.handle(socket,line)}})
    socket.on("close",()=>this.peers.delete(socket)); socket.on("error",()=>this.peers.delete(socket));
    this.peers.add(socket); this.send(socket,{type:"hello",network:this.cfg.network,height:this.node.chain.height,tip:this.node.chain.tip.hash});
  }
  connect(host,port){
    const s=net.createConnection(port,host,()=>this.accept(s)); return s;
  }
  send(s,msg){try{s.write(JSON.stringify(msg)+"\n")}catch{}}
  broadcast(msg){for(const p of this.peers)this.send(p,msg)}
  handle(s,line){
    let m;try{m=JSON.parse(line)}catch{return}
    if(m.type==="hello"){
      if(m.network!==this.cfg.network)return s.destroy();
      if(m.height>this.node.chain.height)this.send(s,{type:"request_blocks",from:this.node.chain.height+1});
    } else if(m.type==="tx"){
      try{this.node.chain.submitTx(m.tx);this.broadcast({type:"tx",tx:m.tx})}catch{}
    } else if(m.type==="request_blocks"){
      this.send(s,{type:"blocks",blocks:this.node.chain.blocks.slice(m.from)});
    } else if(m.type==="blocks"){
      for(const b of m.blocks){try{this.node.chain.applyBlock(b)}catch{break}}
    }
  }
}
