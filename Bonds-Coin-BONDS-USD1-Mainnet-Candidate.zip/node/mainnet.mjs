import fs from "node:fs";
import http from "node:http";
import cfg from "../config/mainnet.json" with {type:"json"};
import {Store} from "./storage.mjs";
import {Chain} from "./chain.mjs";
import {P2P} from "./p2p.mjs";
import {walletNew, makeGenesis, txSign, UNIT, MAX_SUPPLY} from "./protocol.mjs";

const dataDir=process.env.BONDS_DATA_DIR||cfg.dataDir;
fs.mkdirSync(dataDir,{recursive:true});
const walletPath=dataDir+"/node-wallet.json";
let wallet=fs.existsSync(walletPath)?JSON.parse(fs.readFileSync(walletPath)):walletNew();
if(!fs.existsSync(walletPath))fs.writeFileSync(walletPath,JSON.stringify(wallet,null,2),{mode:0o600});

const genesis=makeGenesis(wallet.address);
const store=new Store(dataDir);
const chain=new Chain(cfg,store,genesis);
const p2p=new P2P({chain},cfg); p2p.start();

function send(res,status,data){res.writeHead(status,{"content-type":"application/json","access-control-allow-origin":"*"});res.end(JSON.stringify(data,(_,v)=>typeof v==="bigint"?v.toString():v))}
async function body(req){let s="";for await(const c of req)s+=c;return JSON.parse(s||"{}")}

const server=http.createServer(async(req,res)=>{
  try{
    const u=new URL(req.url,"http://localhost");
    if(req.method==="GET"&&u.pathname==="/"){
      return send(res,200,{name:cfg.name,symbol:cfg.symbol,network:cfg.network,chainId:cfg.chainId,
        height:chain.height,tip:chain.tip.hash,mempool:chain.mempool.size,nodeAddress:wallet.address,supply:chain.totalSupply.toString(),targetPriceUsd:"1.00",pegModel:cfg.pegModel});
    }
    if(req.method==="GET"&&u.pathname==="/blocks")return send(res,200,chain.blocks.slice(-100));
    if(req.method==="GET"&&u.pathname.startsWith("/account/"))return send(res,200,chain.account(u.pathname.split("/")[2]));
    if(req.method==="GET"&&u.pathname==="/peg")return send(res,200,{targetPriceUsd:"1.00",model:cfg.pegModel,supply:chain.totalSupply.toString(),maxSupply:MAX_SUPPLY.toString(),issuer:cfg.issuerAddress});
    if(req.method==="GET"&&u.pathname==="/mempool")return send(res,200,[...chain.mempool.values()]);
    if(req.method==="POST"&&u.pathname==="/tx"){
      const tx=await body(req);const out=chain.submitTx(tx);p2p.broadcast({type:"tx",tx:out});return send(res,200,out);
    }
    if(req.method==="POST"&&u.pathname==="/mine"){
      const b=chain.mine(wallet.address);p2p.broadcast({type:"blocks",blocks:[b]});return send(res,200,b);
    }
    return send(res,404,{error:"not found"});
  }catch(e){return send(res,400,{error:e?.message||String(e)})}
});
server.listen(cfg.rpcPort,cfg.rpcHost,()=>console.log(`BONDS MAINNET node RPC http://${cfg.rpcHost}:${cfg.rpcPort}, P2P ${cfg.p2pPort}`));
