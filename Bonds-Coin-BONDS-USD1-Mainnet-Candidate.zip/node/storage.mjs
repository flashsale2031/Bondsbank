import fs from "node:fs";
import path from "node:path";

export class Store {
  constructor(dir) {
    this.dir=dir; fs.mkdirSync(dir,{recursive:true});
    this.chainFile=path.join(dir,"chain.jsonl");
    this.stateFile=path.join(dir,"state.json");
  }
  loadBlocks() {
    if(!fs.existsSync(this.chainFile)) return [];
    return fs.readFileSync(this.chainFile,"utf8").trim().split("\n").filter(Boolean).map(JSON.parse);
  }
  appendBlock(block) {
    fs.appendFileSync(this.chainFile, JSON.stringify(block)+"\n","utf8");
  }
  saveState(state) {
    fs.writeFileSync(this.stateFile, JSON.stringify(state,(_,v)=>typeof v==="bigint"?v.toString():v,null,2));
  }
  loadState() {
    if(!fs.existsSync(this.stateFile)) return null;
    return JSON.parse(fs.readFileSync(this.stateFile,"utf8"),(_,v)=>typeof v==="string"&&/^\d+n$/.test(v)?BigInt(v.slice(0,-1)):v);
  }
}
