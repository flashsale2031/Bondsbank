# Bonds Bank Authentication

The sign-in/sign-up surface supports four identity providers:

- Email/password
- Google
- Apple
- Yahoo

Provider credentials/client IDs are intentionally not hard-coded. Configure them through the backend authentication broker or Android-safe build/runtime configuration.

## Account linking

All provider identities should resolve to a single Bonds Bank user record using verified provider subject IDs. Do not merge accounts solely on an unverified email address.

## Production requirements

- Use OAuth 2.0 / OpenID Connect with PKCE where supported.
- Validate issuer, audience, nonce, state, redirect URI, and token signature server-side.
- Apple private keys stay server-side.
- Yahoo OAuth secrets stay server-side.
- Google client secrets stay server-side.
- Never put provider client secrets in the APK.
