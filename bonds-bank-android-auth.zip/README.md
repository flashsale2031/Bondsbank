# Bonds Bank Android

Complete native Android/Gradle host for Bonds Bank v1.7.

## Release signing
Release signing is wired through `keystore.properties`, which is intentionally gitignored. The file must contain:

```
storeFile=release/bonds-bank-release.jks
storePassword=...
keyAlias=bonds-bank-release
keyPassword=...
```

Do not commit the keystore or passwords. The app build uses the release signing config for `release` builds. Android recommends keeping signing credentials outside build files. See https://developer.android.com/build/gradle-tips.

## Build

```
./gradlew assembleRelease
```

The release APK is produced under `app/build/outputs/apk/release/`.

## Security note
The included release keystore is a newly generated app-signing key and is unrelated to any Visa credentials. Never reuse the Visa private key as an Android signing key. For production, move the keystore into a dedicated secrets store/CI signer and rotate if exposed.
