import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val signingProps = Properties()
val signingFile = rootProject.file("keystore.properties")
if (signingFile.exists()) signingFile.inputStream().use { signingProps.load(it) }

android {
    namespace = "com.bondsbank.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.bondsbank.app"
        minSdk = 26
        targetSdk = 36
        versionCode = 17
        versionName = "1.7.0"
    }

    signingConfigs {
        create("release") {
            val storeFilePath = signingProps.getProperty("storeFile")
            if (!storeFilePath.isNullOrBlank()) storeFile = rootProject.file(storeFilePath)
            storePassword = signingProps.getProperty("storePassword")
            keyAlias = signingProps.getProperty("keyAlias")
            keyPassword = signingProps.getProperty("keyPassword")
            enableV1Signing = true
            enableV2Signing = true
            enableV3Signing = true
            enableV4Signing = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            signingConfig = signingConfigs.getByName("release")
        }
        debug { applicationIdSuffix = ".debug" }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

dependencies { implementation(kotlin("stdlib")) }
