package com.bondsbank.app

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.ImageView
import android.widget.Button

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.WHITE)
            setPadding(48, 48, 48, 48)
        }
        val logo = ImageView(this).apply {
            setImageResource(com.bondsbank.app.R.drawable.lion_icon)
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }
        root.addView(logo, LinearLayout.LayoutParams(-1, 0, 1f))
        val title = TextView(this).apply { text = "Bonds Bank"; textSize = 28f; setTextColor(Color.BLACK); gravity = Gravity.CENTER }
        root.addView(title, LinearLayout.LayoutParams(-1, 70))
        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progress = 0; progressDrawable.setTint(Color.BLACK)
        }
        root.addView(progress, LinearLayout.LayoutParams(-1, 40))
        val pct = TextView(this).apply { text = "0%"; textSize = 16f; setTextColor(Color.BLACK); gravity = Gravity.CENTER }
        root.addView(pct, LinearLayout.LayoutParams(-1, 50))
        setContentView(root)
        val handler = Handler(Looper.getMainLooper())
        val start = System.currentTimeMillis()
        val tick = object : Runnable {
            override fun run() {
                val p = (((System.currentTimeMillis() - start) / 2200.0) * 100).toInt().coerceIn(0, 100)
                progress.progress = p; pct.text = "$p%"
                if (p < 100) handler.postDelayed(this, 30) else showLanding()
            }
        }
        handler.post(tick)
    }
    private fun showLanding() {
        val signedIn = getSharedPreferences("session", MODE_PRIVATE).getBoolean("signed_in", false)
        if (signedIn) {
            showSimpleScreen("Dashboard")
            return
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.WHITE)
            setPadding(48, 48, 48, 48)
        }
        val title = TextView(this).apply {
            text = "Sign in to Bonds Bank"
            textSize = 28f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(-1, 100))

        listOf("Continue with Google", "Continue with Apple", "Continue with Yahoo", "Continue with Email").forEach { label ->
            val button = Button(this).apply {
                text = label
                setOnClickListener { beginProviderSignIn(label) }
            }
            root.addView(button, LinearLayout.LayoutParams(-1, 64).apply { setMargins(0, 10, 0, 10) })
        }
        setContentView(root)
    }

    private fun beginProviderSignIn(providerLabel: String) {
        // Production implementation delegates to the Bonds Bank authentication backend.
        // OAuth/OIDC secrets are never embedded in the APK.
        getSharedPreferences("session", MODE_PRIVATE).edit().putString("pending_provider", providerLabel).apply()
        showSimpleScreen("$providerLabel authentication")
    }

    private fun showSimpleScreen(label: String) {
        val tv = TextView(this).apply {
            text = label
            textSize = 26f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
            background = ColorDrawable(Color.WHITE)
        }
        setContentView(tv)
    }
}
