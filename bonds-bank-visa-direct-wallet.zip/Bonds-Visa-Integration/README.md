# Bonds Bank — Visa Direct integration patch

Adds a secure integration layer for Visa Direct for Account and Visa Direct for Wallet.

The patch intentionally excludes live credentials and the uploaded private key. Deploy them through a secret manager/secret volume instead.
