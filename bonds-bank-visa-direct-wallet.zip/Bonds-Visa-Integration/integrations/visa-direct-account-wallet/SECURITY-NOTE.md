# Credential handling

The Visa username/password supplied during configuration are treated as secrets and are deliberately not written into this package.

The uploaded PEM was inspected and is a 2048-bit RSA private key. It is not a certificate. Visa mutual TLS requires the Visa-issued X.509 client certificate together with the corresponding private key.

Because the password was pasted into chat, rotate/revoke it in the Visa developer/project console before production use and replace it in the deployment secret store.
