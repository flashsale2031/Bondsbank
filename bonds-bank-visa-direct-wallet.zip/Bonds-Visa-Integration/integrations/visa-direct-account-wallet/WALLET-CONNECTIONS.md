# Bonds Bank Wallet — Connected Accounts & Cards

The Wallet section supports connecting both **bank accounts** and **cards**.

## User experience

1. Wallet → **Add funding source**
2. Choose **Bank account** or **Card**
3. Complete the approved provider's authorization/verification flow
4. Bonds Bank receives a provider token/reference, not raw credentials
5. Show only safe display metadata such as institution/card brand and last four digits
6. The user can set a verified source as a preferred funding source or disconnect it

## Bank accounts

Use an approved account-linking/ACH/open-banking provider for account ownership and account-number verification. Visa Direct Account/Wallet should not be treated as the consumer account-linking mechanism itself. Visa's current documentation describes Account and Wallet as recipient/payout rails and provides Verify/Validate APIs for payout recipients. citeturn0search2turn0search1

## Cards

Use Visa Direct for Card's verification/eligibility capabilities for supported card flows. Visa documents card account validation before saving a card or using it to fund a wallet, and AFT/OCT capabilities for eligible programs. citeturn0search2turn0search4

## Security requirements

- Never store CVV.
- Never store raw PAN or full bank-account numbers unless the approved regulated processor explicitly requires it and the storage architecture is PCI/regulated-data compliant.
- Prefer provider/network tokens and references.
- Encrypt secrets at rest and in transit.
- Redact account/card data from logs.
- Require step-up authentication for adding, removing, or changing a high-risk funding source.
- Run verification before allowing a newly linked source to fund a wallet.

## Important Visa access boundary

Visa Direct Connect only permits payouts to products for which the client has received approval/access authorization. The application therefore keeps Account, Wallet, and Card capabilities behind separate configuration gates. citeturn0search1
