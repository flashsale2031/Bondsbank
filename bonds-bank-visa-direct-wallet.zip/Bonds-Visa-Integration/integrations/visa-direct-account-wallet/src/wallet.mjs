import { visaDirect } from './service.mjs';
import { buildWalletFundingSource, normalizeWalletLink } from './wallet-links.mjs';

export const wallet = {
  /** Attach a previously tokenized/verified external account or card to a Bonds wallet. */
  connect: async (link) => normalizeWalletLink(link),

  /** Remove a link by provider reference. Actual persistence belongs to the wallet service. */
  disconnect: (link) => ({ provider: link.provider, providerReference: link.providerReference, status: 'DISCONNECTED' }),

  /** Create a Visa Direct Wallet payout using a linked recipient wallet reference. */
  payout: async (link, body) => {
    const source = buildWalletFundingSource(link);
    return visaDirect.payout({ ...body, fundingSource: source });
  },

  /** Card verification is exposed through the Visa Direct Card adapter when enabled. */
  verifyCard: async (body) => {
    if (!process.env.VISA_CARD_VERIFY_PATH) {
      throw new Error('VISA_CARD_VERIFY_PATH is not configured');
    }
    const { visaRequest } = await import('./client.mjs');
    return visaRequest(process.env.VISA_CARD_VERIFY_PATH, { method: 'POST', body });
  },
};
