import fs from 'node:fs';
import https from 'node:https';
import { URL } from 'node:url';

const cfg = {
  baseUrl: process.env.VISA_BASE_URL || 'https://sandbox.api.visa.com',
  username: process.env.VISA_USERNAME,
  password: process.env.VISA_PASSWORD,
  certPath: process.env.VISA_CLIENT_CERT_PATH,
  keyPath: process.env.VISA_PRIVATE_KEY_PATH,
  timeout: Number(process.env.VISA_TIMEOUT_MS || 15000),
};

function required(name, value) {
  if (!value) throw new Error(`Missing required Visa configuration: ${name}`);
}

function mtlsAgent() {
  required('VISA_USERNAME', cfg.username);
  required('VISA_PASSWORD', cfg.password);
  required('VISA_CLIENT_CERT_PATH', cfg.certPath);
  required('VISA_PRIVATE_KEY_PATH', cfg.keyPath);

  return new https.Agent({
    cert: fs.readFileSync(cfg.certPath),
    key: fs.readFileSync(cfg.keyPath),
    minVersion: 'TLSv1.2',
    keepAlive: true,
  });
}

export async function visaRequest(path, { method = 'GET', body, headers = {} } = {}) {
  const url = new URL(path, cfg.baseUrl);
  const auth = Buffer.from(`${cfg.username}:${cfg.password}`).toString('base64');
  const payload = body === undefined ? undefined : JSON.stringify(body);

  return new Promise((resolve, reject) => {
    const req = https.request(url, {
      method,
      agent: mtlsAgent(),
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        Authorization: `Basic ${auth}`,
        ...headers,
      },
      timeout: cfg.timeout,
    }, (res) => {
      let text = '';
      res.setEncoding('utf8');
      res.on('data', chunk => { text += chunk; });
      res.on('end', () => {
        let data = text;
        try { data = text ? JSON.parse(text) : null; } catch {}
        resolve({ status: res.statusCode, headers: res.headers, data });
      });
    });

    req.on('timeout', () => req.destroy(new Error('Visa request timed out')));
    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}
