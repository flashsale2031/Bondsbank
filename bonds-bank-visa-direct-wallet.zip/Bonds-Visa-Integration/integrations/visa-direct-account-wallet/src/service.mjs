import { visaRequest } from './client.mjs';

// Exact Visa endpoint paths are kept in deployment configuration because
// Visa may provision Account/Wallet products on different endpoint versions.
const path = (name) => {
  const value = process.env[name];
  if (!value) throw new Error(`Missing Visa endpoint configuration: ${name}`);
  return value;
};

export const visaDirect = {
  balance: (body) => visaRequest(path('VISA_WALLET_BALANCE_PATH'), { method: 'POST', body }),
  validate: (body) => visaRequest(path('VISA_WALLET_VALIDATE_PATH'), { method: 'POST', body }),
  payout: (body) => visaRequest(path('VISA_WALLET_PAYOUT_PATH'), { method: 'POST', body }),
  query: (body) => visaRequest(path('VISA_WALLET_QUERY_PATH'), { method: 'POST', body }),
  cancel: (body) => visaRequest(path('VISA_WALLET_CANCEL_PATH'), { method: 'POST', body }),
};

export const visaDirectCard = {
  verify: (body) => {
    const p = path('VISA_CARD_VERIFY_PATH');
    return visaRequest(p, { method: 'POST', body });
  },
  eligibility: (body) => {
    const p = path('VISA_CARD_ELIGIBILITY_PATH');
    return visaRequest(p, { method: 'POST', body });
  },
};
