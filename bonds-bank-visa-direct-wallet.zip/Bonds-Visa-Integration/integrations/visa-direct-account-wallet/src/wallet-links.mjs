/**
 * Wallet connection orchestration.
 *
 * A wallet can have two kinds of funding/withdrawal instruments:
 *  - bank accounts: linked through an approved account-linking/ACH provider
 *  - cards: tokenized/verified through an approved card-network integration
 *
 * Never store raw PAN, CVV, full bank-account numbers, or provider secrets.
 * Persist provider-issued tokens/references and masked display metadata only.
 */

const SUPPORTED = new Set(['BANK_ACCOUNT', 'CARD']);

export function normalizeWalletLink(input) {
  if (!input || !SUPPORTED.has(input.type)) {
    throw new Error('Wallet link type must be BANK_ACCOUNT or CARD');
  }
  if (!input.provider || !input.providerReference) {
    throw new Error('Wallet link provider and providerReference are required');
  }

  return {
    id: input.id,
    type: input.type,
    provider: input.provider,
    providerReference: input.providerReference,
    displayName: input.displayName || (input.type === 'CARD' ? 'Card' : 'Bank account'),
    last4: input.last4 || null,
    brand: input.brand || null,
    currency: input.currency || null,
    status: input.status || 'PENDING_VERIFICATION',
    verifiedAt: input.verifiedAt || null,
    createdAt: input.createdAt || new Date().toISOString(),
  };
}

export function buildWalletFundingSource(link) {
  const normalized = normalizeWalletLink(link);
  return {
    type: normalized.type,
    provider: normalized.provider,
    providerReference: normalized.providerReference,
    currency: normalized.currency,
  };
}
