# Bonds Bank — Visa Direct Account & Wallet

This integration layer is prepared for Visa Direct for Account and Visa Direct for Wallet using Visa's mutual-TLS authentication model.

## Security

- Real Visa credentials are **not stored in source control**.
- The Visa private key is expected at `VISA_PRIVATE_KEY_PATH` and must be supplied through a secret volume/secret manager.
- The Visa-issued client certificate must be supplied separately as `VISA_CLIENT_CERT_PATH`. A private key by itself is not an X.509 client certificate.
- Passwords, private keys, PANs, CVVs, SSNs, tokens, and MLE secrets must never be logged.
- Use sandbox first. Production requires Visa onboarding/certification and approved access.

## Configuration

Copy `.env.example` into the deployment secret configuration and populate:

- `VISA_USERNAME`
- `VISA_PASSWORD`
- `VISA_CLIENT_CERT_PATH`
- `VISA_PRIVATE_KEY_PATH`
- `VISA_INITIATING_PARTY_ID`
- `VISA_MLE_KEY_ID`
- `VISA_MLE_SHARED_SECRET`

The Account/Wallet APIs require Visa-approved access and an Initiating Party ID. Visa's current documentation also states that Message Level Encryption (MLE) is required for Visa Direct certification and production.

## Transaction flow

1. Validate recipient details.
2. Validate the payout payload.
3. Check funding/settlement balance where applicable.
4. Submit payout with a unique client reference ID.
5. Persist Visa's payout ID and correlation information.
6. Handle status/return notifications.
7. Support query and cancellation where Visa permits cancellation.
8. Reconcile ledger entries against Visa notifications.

No live transaction is executed by this repository's setup step.
