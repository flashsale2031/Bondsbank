package com.bondsbank.admin

import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import android.content.Context

class MainActivity : android.app.Activity() {
    private lateinit var content: LinearLayout
    private val users = listOf(
        "Avery Johnson" to "avery@example.com",
        "Jordan Lee" to "jordan@example.com",
        "Morgan Smith" to "morgan@example.com"
    )
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); showDashboard() }

    private fun base(title: String): LinearLayout {
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE) }
        val bar = LinearLayout(this).apply { setPadding(24,24,24,24); gravity=Gravity.CENTER_VERTICAL; setBackgroundColor(Color.BLACK) }
        val t=TextView(this).apply { text=title; textSize=22f; setTextColor(Color.WHITE); layoutParams=LinearLayout.LayoutParams(0,-2,1f) }
        bar.addView(t); root.addView(bar)
        content=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,24,24,24) }
        root.addView(content, LinearLayout.LayoutParams(-1,0,1f)); return root
    }
    private fun button(text:String, action:()->Unit): Button = Button(this).apply { this.text=text; setOnClickListener{action()}; isAllCaps=false }
    private fun showDashboard(){
        val root=base("Bonds Bank Admin")
        content.addView(TextView(this).apply{text="Administrator Console";textSize=28f;setTextColor(Color.BLACK)})
        content.addView(TextView(this).apply{text="Role-based access required. Sensitive identity data is never displayed here.";textSize=14f})
        content.addView(button("User Management"){showUsers()})
        content.addView(button("Verification & Account Status"){showVerification()})
        content.addView(button("Audit Log"){showAudit()})
        content.addView(button("Security / Admin Sessions"){showSecurity()})
        setContentView(root)
    }
    private fun showUsers(){
        val root=base("User Management")
        val search=EditText(this).apply{hint="Search name or email"}; content.addView(search)
        users.forEach{ (name,email)->
            val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(0,18,0,18)}
            box.addView(TextView(this).apply{text=name; textSize=19f})
            box.addView(TextView(this).apply{text=email})
            box.addView(TextView(this).apply{text="Status: Active • Accounts: Checking, Savings"})
            box.addView(button("View profile"){showProfile(name,email)})
            content.addView(box)
        }
        content.addView(button("Back"){showDashboard()});setContentView(root)
    }
    private fun showProfile(name:String,email:String){
        val root=base("User Profile")
        content.addView(TextView(this).apply{text=name; textSize=24f})
        content.addView(TextView(this).apply{text=email})
        content.addView(TextView(this).apply{text="Identity: Verified\nPhone: Verified\n2-step authentication: Enabled\nCredit access: Eligible"})
        content.addView(button("Suspend user"){toast("Suspension request queued for authorized backend review")})
        content.addView(button("Restore user"){toast("Restore request queued for authorized backend review")})
        content.addView(button("Back"){showUsers()});setContentView(root)
    }
    private fun showVerification(){
        val root=base("Verification & Accounts")
        content.addView(TextView(this).apply{text="Review verification state and account eligibility without exposing raw SSN, ID images, passwords, or authentication secrets.";textSize=16f})
        content.addView(button("Verification queue"){toast("Backend verification queue")})
        content.addView(button("Credit eligibility"){toast("Credit eligibility is enforced server-side")})
        content.addView(button("Back"){showDashboard()});setContentView(root)
    }
    private fun showAudit(){
        val root=base("Audit Log")
        content.addView(TextView(this).apply{text="Immutable administrative events";textSize=22f})
        content.addView(TextView(this).apply{text="• User profile viewed\n• Verification status reviewed\n• Admin session authenticated\n• No raw credentials or SSN values are logged"})
        content.addView(button("Back"){showDashboard()});setContentView(root)
    }
    private fun showSecurity(){
        val root=base("Admin Security")
        content.addView(TextView(this).apply{text="Require strong authentication, role-based permissions, device/session controls, and step-up authentication for sensitive actions.";textSize=16f})
        content.addView(button("Back"){showDashboard()});setContentView(root)
    }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
}
