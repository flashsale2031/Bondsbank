# Bonds Bank Administrator App v1.0

Separate Android administrator console for Bonds Bank user management.

## Included
- User search and profile review
- Account/status and verification review
- Credit eligibility status (read-only UI; server-side enforcement required)
- Audit log viewer placeholder
- Admin security/session section
- No raw SSN, ID images, passwords, OTPs, or auth secrets displayed or logged
- Role-based access boundary documented for backend integration

## Security requirements for production
- Use a dedicated admin identity provider and short-lived tokens.
- Enforce RBAC/ABAC server-side for every operation.
- Require MFA and step-up authentication for sensitive actions.
- Keep immutable audit logs.
- Never put banking credentials or signing secrets in the APK.
- Replace demo data with authenticated API calls before production.

## Build
`./gradlew assembleDebug` or `./gradlew assembleRelease`
