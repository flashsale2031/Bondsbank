# Bonds Bank Online POS

Merchant-facing POS web module for Business Checking merchants. Supports a unified payment-method selector for card, connected wallet, bank/ACH, Apple Pay, Google Pay, and cash recording.

## Production integration
The browser must call a PCI-compliant payment processor or regulated banking/payment API. Do not collect/store PAN, CVV, bank passwords, wallet secrets, or authentication secrets in this frontend. Server-side endpoints should create payment intents, authorize/capture, void, refund, reconcile, and settle to the merchant's verified Business Checking account.

Suggested API contract: `POST /v1/pos/payment-intents`, `POST /v1/pos/payments/{id}/capture`, `POST /v1/pos/payments/{id}/refund`, `POST /v1/pos/payments/{id}/void`, `GET /v1/pos/transactions`.
