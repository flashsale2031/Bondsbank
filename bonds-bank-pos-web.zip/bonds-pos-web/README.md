# Bonds Bank Online POS Web Package

Version 1.2. Includes the customer-facing web POS and shared payment/withdrawal contracts.

The POS is designed for Business Checking merchants and provides a single online checkout interface for supported payment methods plus standard and Instant Deposit withdrawals.

All financial execution must be performed by authenticated backend services and authorized providers. This package does not contain production payment credentials or private keys.
