# Bonds Bank Online POS Web v1.2

Standalone responsive web POS for Business Checking merchants.

## Payment methods
- Cards: Visa, Mastercard, American Express, Discover
- Connected wallet
- ACH / verified bank account
- Apple Pay
- Google Pay
- Cash recording

## Withdrawals
- Standard withdrawal
- Instant Deposit withdrawal option
- Business Checking or connected bank destination

This is a browser UI and payment-orchestration shell. Production card, bank, and wallet credentials must be collected and tokenized by PCI-compliant or regulated payment providers. The browser never stores CVV, raw bank credentials, or wallet secrets.

## Run
Open `index.html` in a browser, or serve the `pos-web` directory with any static web server.

## Production
Connect the UI to authenticated server endpoints for authorization, capture, refund, settlement, and withdrawal execution. Enforce merchant authorization, idempotency, limits, provider eligibility, and audit logging server-side.
