# Backend integration boundaries

Customer API areas: authentication, sessions, accounts, ledger, transfers, wallet funding sources, card tokenization, identity verification, phone verification, 2FA, credit eligibility, POS/merchant operations.

Admin API areas: users, account status, verification status, privileged actions, audit events. Every admin endpoint must enforce server-side RBAC, session assurance, and audit logging.

The web UI intentionally uses placeholders for privileged or financial operations until connected to the real backend.


## POS withdrawals / instant deposit

The POS merchant console supports a withdrawal option called **Instant Deposit**. It is a withdrawal/disbursement request from the merchant's available POS balance to an eligible Business Checking or connected bank destination.

Backend contract should expose: `POST /v1/pos/withdrawals` with `{ amount, currency, destination_id, speed: "instant" | "standard", idempotency_key }`. The backend must verify merchant authorization, available balance, destination ownership, limits, risk/fraud controls, provider eligibility, fees, and settlement state before executing.

The browser must never directly move funds or bypass provider controls. "Instant" means expedited provider settlement only when the configured payment/disbursement provider supports it; otherwise the request must remain pending or be rejected with a clear reason.
